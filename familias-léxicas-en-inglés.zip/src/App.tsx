/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect } from 'react';
import MobileFrame from './components/MobileFrame';
import VocabularyExplorer from './components/VocabularyExplorer';
import GrammarRulesView from './components/GrammarRulesView';
import InteractiveExercises from './components/InteractiveExercises';
import QuizSection from './components/QuizSection';
import UserProfile from './components/UserProfile';
import ComparativeNuancesView from './components/ComparativeNuancesView';
import { wordFamilies } from './data/wordFamilies';
import { getSafeSolvedExercises, getSafeQuizHistory } from './utils/security';
import { LangCode, t, getTranslatedWord } from './utils/translator';

// Lucide icon imports
import { 
  Home, 
  BookOpen, 
  Award, 
  GraduationCap, 
  Sparkles, 
  PenTool, 
  Zap, 
  Gamepad2, 
  ChevronRight, 
  RotateCcw,
  Star,
  User,
  Layers
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type SubTab = 'home' | 'explorer' | 'rules' | 'practice' | 'quiz' | 'nuances' | 'profile';

export default function App() {
  const [activeTab, setActiveTab] = useState<SubTab>('home');
  const [userSolvedCount, setUserSolvedCount] = useState(0);
  const [quizAttemptCount, setQuizAttemptCount] = useState(0);
  const [currentLanguage, setCurrentLanguage] = useState<LangCode>('es');
  
  // Word of the Day
  const [wordOfTheDay, setWordOfTheDay] = useState(wordFamilies[0]);

  // Load language settings & progress metrics
  useEffect(() => {
    const savedLang = localStorage.getItem('user_preferred_language') as LangCode;
    if (savedLang) {
      setCurrentLanguage(savedLang);
    }

    const updateStats = () => {
      const solved = getSafeSolvedExercises();
      setUserSolvedCount(solved.length);

      const history = getSafeQuizHistory();
      setQuizAttemptCount(history.length);
    };

    updateStats();
  }, [activeTab]);

  const handleLanguageChange = (lang: LangCode) => {
    setCurrentLanguage(lang);
    localStorage.setItem('user_preferred_language', lang);
  };

  const handleStatsRefresh = () => {
    const solved = getSafeSolvedExercises();
    setUserSolvedCount(solved.length);

    const history = getSafeQuizHistory();
    setQuizAttemptCount(history.length);
  };

  const selectWordOfTheDay = () => {
    // Pick today's word based on the day of the month
    const day = new Date().getDate();
    const index = day % wordFamilies.length;
    setWordOfTheDay(wordFamilies[index]);
  };

  useEffect(() => {
    selectWordOfTheDay();
  }, []);

   const renderActiveTab = () => {
    switch (activeTab) {
      case 'home':
        return renderHomeView();
      case 'explorer':
        return <VocabularyExplorer currentLanguage={currentLanguage} />;
      case 'rules':
        return <GrammarRulesView />;
      case 'practice':
        return <InteractiveExercises currentLanguage={currentLanguage} />;
      case 'quiz':
        return <QuizSection currentLanguage={currentLanguage} />;
      case 'nuances':
        return <ComparativeNuancesView currentLanguage={currentLanguage} />;
      case 'profile':
        return (
          <UserProfile 
            currentLanguage={currentLanguage} 
            onLanguageChange={handleLanguageChange} 
            onRequestStatsRefresh={handleStatsRefresh}
          />
        );
    }
  };

  const renderHomeView = () => {
    return (
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-5 pb-8 bg-slate-50">
        {/* Welcome Block Banner */}
        <div className="relative bg-white border border-slate-200 rounded-2xl p-5 overflow-hidden shadow-sm">
          <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-blue-500/5 rounded-full blur-xl pointer-events-none" />
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-widest text-blue-600 font-extrabold flex items-center gap-1.5 select-none font-sans">
              <Sparkles className="w-3.5 h-3.5 animate-pulse text-blue-600" />
              {t('masterLevel', currentLanguage)}
            </span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 mt-1 leading-tight">
            {t('welcome', currentLanguage)}
          </h2>
          <p className="text-xs text-slate-600 leading-relaxed mt-1.5 font-sans">
            {t('tagline', currentLanguage)}
          </p>

          <div className="grid grid-cols-2 gap-3 mt-4 border-t border-slate-100 pt-3.5">
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-150 text-left">
              <span className="text-[9px] text-slate-400 uppercase tracking-wider font-extrabold block">Ejercicios</span>
              <span className="text-[13px] font-bold font-mono text-blue-600 mt-0.5 block">{userSolvedCount} {t('exercisesSolved', currentLanguage)}</span>
            </div>
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-150 text-left">
              <span className="text-[9px] text-slate-400 uppercase tracking-wider font-extrabold block">Tests</span>
              <span className="text-[13px] font-bold font-mono text-indigo-600 mt-0.5 block">{quizAttemptCount} {t('quizzesCompleted', currentLanguage)}</span>
            </div>
          </div>
        </div>

        {/* Word of the Day Block Card */}
        <div className="flex flex-col gap-2">
          <span className="text-[10px] text-slate-400 uppercase tracking-widest font-extrabold px-1">{t('wordOfTheDay', currentLanguage)}</span>
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex flex-col gap-2.5 relative">
            <div className="flex items-start justify-between">
              <div className="flex items-baseline gap-1.5 flex-wrap">
                <h3 className="text-2xl font-black font-sans text-slate-900 leading-none tracking-tight">
                  {wordOfTheDay.lexeme}
                </h3>
                <span className="text-xs text-slate-500 font-semibold">({getTranslatedWord(wordOfTheDay.lexeme, wordOfTheDay.lexemeTranslation, currentLanguage)})</span>
              </div>
              <span className="text-[9px] px-2 py-0.5 rounded-full bg-blue-600 text-white uppercase tracking-wider font-bold">
                {wordOfTheDay.category}
              </span>
            </div>

            <p className="text-xs text-slate-650 italic">
              "{wordOfTheDay.lexemeDefinition}"
            </p>

            <button
              onClick={() => setActiveTab('explorer')}
              className="mt-1 py-2.5 px-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl flex items-center justify-between text-xs text-slate-700 font-bold group transition-all cursor-pointer shadow-sm"
            >
              <span>{t('viewFamilyTree', currentLanguage)}</span>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>

        {/* Shortcuts quick access modules listing */}
        <div className="flex flex-col gap-2">
          <span className="text-[10px] text-slate-400 uppercase tracking-widest font-extrabold px-1">Módulos de Aprendizaje</span>
          
          <div className="flex flex-col gap-2.5">
            {/* Explorer button */}
            <div 
              onClick={() => setActiveTab('explorer')}
              className="bg-white hover:bg-slate-50/50 border border-slate-200 p-3.5 rounded-2xl cursor-pointer transition-all flex items-center gap-3.5 relative select-none shadow-sm"
            >
              <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100/50 flex items-center justify-center text-blue-600 font-bold shrink-0">
                <BookOpen className="w-5 h-5" />
              </div>
              <div className="flex-1 text-left min-w-0">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Explorar Familias</h4>
                <p className="text-[10px] text-slate-500 truncate">Universo de 15 familias, sinónimos y antónimos</p>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 mr-1 shrink-0" />
            </div>

            {/* Rules button */}
            <div 
              onClick={() => setActiveTab('rules')}
              className="bg-white hover:bg-slate-50/50 border border-slate-200 p-3.5 rounded-2xl cursor-pointer transition-all flex items-center gap-3.5 relative select-none shadow-sm"
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100/50 flex items-center justify-center text-indigo-600 font-bold shrink-0">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div className="flex-1 text-left min-w-0">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Reglas Maestras</h4>
                <p className="text-[10px] text-slate-500 truncate">Asociación de sufijos, excepciones y Método de Oro</p>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 mr-1 shrink-0" />
            </div>

            {/* Exercises button */}
            <div 
              onClick={() => setActiveTab('practice')}
              className="bg-white hover:bg-slate-50/50 border border-slate-200 p-3.5 rounded-2xl cursor-pointer transition-all flex items-center gap-3.5 relative select-none shadow-sm"
            >
              <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-100/50 flex items-center justify-center text-rose-400 font-bold shrink-0">
                <PenTool className="w-4 h-4" />
              </div>
              <div className="flex-1 text-left min-w-0">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Práctica Fija</h4>
                <p className="text-[10px] text-slate-500 truncate">Ejercicios interactivos con respuestas inmediatas</p>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 mr-1 shrink-0" />
            </div>

            {/* Quizzes button */}
            <div 
              onClick={() => setActiveTab('quiz')}
              className="bg-white hover:bg-slate-50/50 border border-slate-200 p-3.5 rounded-2xl cursor-pointer transition-all flex items-center gap-3.5 relative select-none shadow-sm"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-100/50 flex items-center justify-center text-amber-400 font-bold shrink-0">
                <Award className="w-5 h-5" />
              </div>
              <div className="flex-1 text-left min-w-0">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Quiz Evaluativo</h4>
                <p className="text-[10px] text-slate-500 truncate">Desafíos personalizados bajo presión y temporizador</p>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 mr-1 shrink-0" />
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <MobileFrame>
      {/* Top Application Bar Header */}
      <header className="h-14 bg-white border-b border-slate-200 px-4 flex justify-between items-center select-none shrink-0 z-40 relative shadow-sm">
        <div className="flex items-center gap-2">
          {/* Circular logo mark element */}
          <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-sm shadow-sm select-none">
            W
          </div>
          <div>
            <h1 className="text-sm font-bold text-slate-900 uppercase tracking-tight leading-none">LEXI<span className="text-blue-600">BUILD</span></h1>
            <span className="text-[9px] text-slate-500 font-extrabold uppercase mt-0.5 tracking-widest block">Lexical Master</span>
          </div>
        </div>

        {/* Dynamic language abbreviation indicator & Profile switcher */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1 bg-slate-50 px-2 py-1 rounded-full border border-slate-100">
            <span className="text-[10px] text-slate-650 font-mono font-black select-none">
              {currentLanguage.toUpperCase()}➔EN
            </span>
          </div>

          <button
            onClick={() => setActiveTab(activeTab === 'profile' ? 'home' : 'profile')}
            className={`p-2 rounded-xl border cursor-pointer transition-all ${
              activeTab === 'profile'
                ? 'bg-blue-50 border-blue-200 text-blue-600'
                : 'bg-slate-50 border-slate-150 text-slate-500 hover:text-slate-800'
            }`}
            title="Mi Perfil"
          >
            <User className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Switchable Tab Page Content */}
      <main className="flex-1 flex flex-col overflow-hidden bg-slate-50">
        {renderActiveTab()}
      </main>

      {/* Bottom Application Navigation Bar */}
      <nav id="bottom-navigation" className="h-16 bg-white border-t border-slate-200 px-2 flex justify-between items-center shrink-0 z-40 select-none shadow-[0_-1px_3px_rgba(0,0,0,0.015)]">
        
        {/* Home Tab Trigger */}
        <button
          onClick={() => setActiveTab('home')}
          className={`flex-1 py-1 flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
            activeTab === 'home' ? 'text-blue-600 font-black scale-102' : 'text-slate-400 hover:text-slate-650'
          }`}
        >
          <Home className={`w-4.5 h-4.5 ${activeTab === 'home' ? 'stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
          <span className="text-[8.5px] uppercase tracking-wider font-extrabold">{t('home', currentLanguage)}</span>
        </button>

        {/* Explorer Tab Trigger */}
        <button
          onClick={() => setActiveTab('explorer')}
          className={`flex-1 py-1 flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
            activeTab === 'explorer' ? 'text-blue-600 font-black scale-102' : 'text-slate-400 hover:text-slate-650'
          }`}
        >
          <BookOpen className={`w-4.5 h-4.5 ${activeTab === 'explorer' ? 'stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
          <span className="text-[8.5px] uppercase tracking-wider font-extrabold">{t('family', currentLanguage)}</span>
        </button>

        {/* Nuances Tab Trigger (Comparative Nuances - Screenshot 2) */}
        <button
          onClick={() => setActiveTab('nuances')}
          className={`flex-1 py-1 flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
            activeTab === 'nuances' ? 'text-blue-600 font-black scale-102' : 'text-slate-400 hover:text-slate-650'
          }`}
        >
          <Layers className={`w-4.5 h-4.5 ${activeTab === 'nuances' ? 'stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
          <span className="text-[8.5px] uppercase tracking-wider font-extrabold">{t('nuances', currentLanguage)}</span>
        </button>

        {/* Practice Tab Trigger */}
        <button
          onClick={() => setActiveTab('practice')}
          className={`flex-1 py-1 flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
            activeTab === 'practice' ? 'text-blue-600 font-black scale-102' : 'text-slate-400 hover:text-slate-650'
          }`}
        >
          <PenTool className={`w-4.5 h-4.5 ${activeTab === 'practice' ? 'stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
          <span className="text-[8.5px] uppercase tracking-wider font-extrabold">Desafíos</span>
        </button>

        {/* Quizzes Tab Trigger */}
        <button
          onClick={() => setActiveTab('quiz')}
          className={`flex-1 py-1 flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
            activeTab === 'quiz' ? 'text-blue-600 font-black scale-102' : 'text-slate-400 hover:text-slate-650'
          }`}
        >
          <Award className={`w-4.5 h-4.5 ${activeTab === 'quiz' ? 'stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
          <span className="text-[8.5px] uppercase tracking-wider font-extrabold">{t('quizzes', currentLanguage)}</span>
        </button>
      </nav>
    </MobileFrame>
  );
}
