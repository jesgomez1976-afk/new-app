/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { WordFamily, WordForm, WordFormKey } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, HelpCircle, Check, BookOpen, Volume2 } from 'lucide-react';
import { safeSpeech } from '../utils/security';
import { LangCode, t, getTranslatedWord, getTranslatedDefinition, getTranslatedExample } from '../utils/translator';

interface WordFamilyTreeProps {
  family: WordFamily;
  currentLanguage: LangCode;
}

export default function WordFamilyTree({ family, currentLanguage }: WordFamilyTreeProps) {
  const [selectedForm, setSelectedForm] = useState<WordFormKey>('noun');

  const formKeys: WordFormKey[] = ['verb', 'noun', 'adjective', 'adverb'];

  const getFormLabel = (key: WordFormKey) => {
    switch (key) {
      case 'verb': return t('verb', currentLanguage);
      case 'noun': return t('noun', currentLanguage);
      case 'adjective': return t('adjective', currentLanguage);
      case 'adverb': return t('adverb', currentLanguage);
    }
  };

  const getFormColor = (key: WordFormKey) => {
    switch (key) {
      case 'verb': return 'bg-rose-50 border-rose-350 text-rose-700 shadow-sm';
      case 'noun': return 'bg-teal-50 border-teal-350 text-teal-700 shadow-sm';
      case 'adjective': return 'bg-indigo-50 border-indigo-350 text-indigo-700 shadow-sm';
      case 'adverb': return 'bg-amber-50 border-amber-350 text-amber-700 shadow-sm';
    }
  };

  const getActiveBadgeColor = (key: WordFormKey) => {
    switch (key) {
      case 'verb': return 'bg-rose-50 border border-rose-200 text-rose-700 shadow-sm';
      case 'noun': return 'bg-teal-50 border border-teal-200 text-teal-700 shadow-sm';
      case 'adjective': return 'bg-indigo-50 border border-indigo-200 text-indigo-700 shadow-sm';
      case 'adverb': return 'bg-amber-50 border border-amber-200 text-amber-700 shadow-sm';
    }
  };

  const speakWord = (word: string) => {
    safeSpeech(word);
  };

  const activeForm = family.forms[selectedForm];

  return (
    <div className="flex flex-col gap-5 p-1">
      {/* Root Lexeme Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm text-center relative overflow-hidden">
        <div className="absolute top-0 right-0 px-2.5 py-0.5 bg-blue-50 border-b border-l border-blue-200 text-[9px] font-mono font-bold text-blue-600 rounded-bl-lg">
          {t('rootLexeme', currentLanguage).toUpperCase()}
        </div>
        
        <span className="text-xs uppercase tracking-widest text-slate-400 font-bold block mb-1">{t('rootLexeme', currentLanguage)}</span>
        <h3 className="text-3xl font-bold text-slate-900 tracking-tight select-none">
          {family.lexeme}
        </h3>
        <p className="text-xs text-slate-600 italic mt-1.5 max-w-xs mx-auto">
          "{family.lexemeDefinition}"
        </p>
        <div className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1 bg-slate-50 rounded-full border border-slate-200">
          <span className="text-[10px] text-slate-500 font-bold">{t('translationBase', currentLanguage)}</span>
          <span className="text-xs font-bold text-blue-600">{getTranslatedWord(family.lexeme, family.lexemeTranslation, currentLanguage)}</span>
        </div>
      </div>

      {/* Visual Family Tree Map (Vertical Chain) */}
      <div className="relative flex flex-col items-center py-2">
        {/* Branch connector line background */}
        <div className="absolute top-0 bottom-0 left-12 w-0.5 bg-slate-200 -z-10"></div>

        <div className="w-full flex flex-col gap-3.5">
          {formKeys.map((key, i) => {
            const form = family.forms[key];
            const isSelected = selectedForm === key;
            const hasForm = form !== null;

            return (
              <motion.div
                key={key}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
                onClick={() => hasForm && setSelectedForm(key)}
                className={`relative flex items-center gap-4 p-3 rounded-xl border transition-all cursor-pointer select-none ${
                  !hasForm 
                    ? 'opacity-40 bg-slate-100 border-slate-200 cursor-not-allowed'
                    : isSelected
                      ? getFormColor(key) + ' border-[2px] font-bold scale-[1.01]'
                      : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-slate-300 shadow-xs'
                }`}
              >
                {/* SVG Pointer indicators */}
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-mono shrink-0 transition-all ${
                  isSelected ? 'bg-blue-600 text-white font-black scale-110 shadow-sm' : 'bg-slate-100 text-slate-500'
                }`}>
                  {i + 1}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] font-bold uppercase tracking-wider ${isSelected ? 'text-slate-900' : 'text-slate-400'}`}>
                      {getFormLabel(key)}
                    </span>
                    {form?.suffix && form.suffix !== 'none' && (
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-500 font-mono">
                        {form.suffix}
                      </span>
                    )}
                  </div>
                  <div className="flex items-baseline gap-1.5">
                    <span className={`text-base font-bold font-sans truncate ${isSelected ? 'text-slate-950 font-black' : 'text-slate-800'}`}>
                      {hasForm ? form.word : 'No disponible'}
                    </span>
                    {hasForm && isSelected && (
                      <button 
                        onClick={(e) => { e.stopPropagation(); speakWord(form.word); }}
                        className="p-1 hover:bg-black/5 rounded cursor-pointer transition-colors"
                      >
                        <Volume2 className="w-3.5 h-3.5 text-blue-600" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="shrink-0">
                  {hasForm ? (
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center border transition-colors ${
                      isSelected ? 'bg-blue-600 text-white border-blue-600' : 'border-slate-200 bg-slate-50 text-slate-400'
                    }`}>
                      <Check className="w-3 h-3" />
                    </div>
                  ) : (
                    <span className="text-[9px] text-slate-400 font-medium">N/A</span>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Dynamic Detail Card Drawer */}
      <AnimatePresence mode="wait">
        {activeForm ? (
          <motion.div
            key={selectedForm}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="bg-white rounded-2xl border border-slate-200 p-4.5 shadow-sm flex flex-col gap-3"
          >
            <div className="flex items-center justify-between">
              <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${getActiveBadgeColor(selectedForm)}`}>
                {getFormLabel(selectedForm)}
              </span>
              <span className="text-xs text-slate-500 flex items-center gap-1 font-semibold">
                <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                Definición & Uso
              </span>
            </div>

            <div className="flex items-baseline gap-2">
              <h4 className="text-xl font-bold text-slate-900">{activeForm.word}</h4>
              <span className="text-xs text-blue-600 font-bold">({getTranslatedWord(activeForm.word, activeForm.translation, currentLanguage)})</span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed font-sans">
              {getTranslatedDefinition(activeForm.word, activeForm.definition, currentLanguage)}
            </p>

            <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200">
              <span className="text-[10px] text-blue-600 font-bold block mb-1 uppercase tracking-wider">{t('example', currentLanguage)}:</span>
              <p className="text-xs font-semibold text-slate-800 font-sans leading-relaxed">
                "{activeForm.example}"
              </p>
              <p className="text-[11px] text-slate-500 italic mt-1">
                ➔ {getTranslatedExample(activeForm.word, activeForm.exampleTranslation, currentLanguage)}
              </p>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-100 pt-2.5">
              <div className="flex items-center gap-1">
                <span className="font-bold text-slate-450">Sufijo:</span>
                <span className="font-mono font-bold text-blue-600 bg-blue-50/50 px-1.5 py-0.5 rounded border border-blue-105/10">{activeForm.suffix}</span>
              </div>
              {activeForm.prefix && (
                <div className="flex items-center gap-1">
                  <span className="font-bold text-slate-450">Prefijo:</span>
                  <span className="font-mono font-bold text-indigo-600 bg-indigo-50/50 px-1.5 py-0.5 rounded border border-indigo-105/10">{activeForm.prefix}</span>
                </div>
              )}
            </div>
          </motion.div>
        ) : (
          <div className="text-center p-5 bg-white rounded-2xl border border-slate-200 text-slate-400 text-xs shadow-sm">
            Selecciona una forma de palabra para ver su desglose gramatical completo.
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
