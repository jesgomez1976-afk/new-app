/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { wordFamilies } from '../data/wordFamilies';
import { WordFamily, WordFormKey } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Award, Zap, Timer, HelpCircle, ArrowRight, Check, X, ClipboardCheck, History, RefreshCcw } from 'lucide-react';
import { getSafeQuizHistory, saveSafeQuizHistory, validateCategoryFilter, sanitizeString } from '../utils/security';

interface GeneratedQuestion {
  id: string;
  type: 'verb-to-noun' | 'noun-to-adj' | 'adj-to-adv' | 'translation';
  questionText: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  wordFamilyId: string;
}

interface LocalQuizStats {
  score: number;
  total: number;
  date: string;
  category: string;
}

export default function QuizSection() {
  const [quizState, setQuizState] = useState<'setup' | 'active' | 'completed'>('setup');
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [numQuestions, setNumQuestions] = useState<number>(5);
  const [enableTimer, setEnableTimer] = useState<boolean>(true);

  // Active quiz variables
  const [questions, setQuestions] = useState<GeneratedQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [secondsLeft, setSecondsLeft] = useState<number>(20);
  const [history, setHistory] = useState<LocalQuizStats[]>([]);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Load historical quiz results securely from localStorage
    const savedHistory = getSafeQuizHistory();
    setHistory(savedHistory);
  }, []);

  // Timer loop
  useEffect(() => {
    if (quizState === 'active' && enableTimer && !isAnswered) {
      setSecondsLeft(20);
      timerRef.current = setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            // Time out!
            clearInterval(timerRef.current!);
            handleAnswerSubmit('__timeout__');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [quizState, currentIndex, isAnswered, enableTimer]);

  const generateQuiz = () => {
    // Filter families by category
    const pool = selectedCategory === 'todos' 
      ? wordFamilies 
      : wordFamilies.filter(f => f.category === selectedCategory);

    if (pool.length < 2) return; // safety boundary

    const quizList: GeneratedQuestion[] = [];
    const questionTypes: ('verb-to-noun' | 'noun-to-adj' | 'adj-to-adv' | 'translation')[] = 
      ['verb-to-noun', 'noun-to-adj', 'adj-to-adv', 'translation'];

    for (let i = 0; i < numQuestions; i++) {
      // Pick a random family
      const family = pool[Math.floor(Math.random() * pool.length)];
      const type = questionTypes[Math.floor(Math.random() * questionTypes.length)];

      let questionText = '';
      let correctAnswer = '';
      let explanation = '';
      let options: string[] = [];

      try {
        if (type === 'verb-to-noun' && family.forms.noun && family.forms.verb) {
          questionText = `¿Cuál es el SUSTANTIVO derivado del verbo "${family.forms.verb.word}"?`;
          correctAnswer = family.forms.noun.word;
          explanation = `El verbo es "${family.forms.verb.word}". Su forma sustantiva asociada es "${correctAnswer}" (sufijo ${family.forms.noun.suffix}).`;
          
          // options from other nouns
          const others = pool.filter(p => p.id !== family.id && p.forms.noun).map(p => p.forms.noun!.word);
          options = shuffleArray([correctAnswer, ...others.slice(0, 3)]);
        } 
        else if (type === 'noun-to-adj' && family.forms.adjective && family.forms.noun) {
          questionText = `Convierte el sustantivo "${family.forms.noun.word}" en su forma de ADJETIVO adecuada:`;
          correctAnswer = family.forms.adjective.word;
          explanation = `El sustantivo es "${family.forms.noun.word}". Le corresponde el adjetivo "${correctAnswer}" (sufijo ${family.forms.adjective.suffix}).`;
          
          const others = pool.filter(p => p.id !== family.id && p.forms.adjective).map(p => p.forms.adjective!.word);
          options = shuffleArray([correctAnswer, ...others.slice(0, 3)]);
        } 
        else if (type === 'adj-to-adv' && family.forms.adverb && family.forms.adjective) {
          questionText = `¿Cuál es el ADVERBIO correcto correspondiente para el adjetivo "${family.forms.adjective.word}"?`;
          correctAnswer = family.forms.adverb.word;
          explanation = `De acuerdo con la regla maestra, el adjetivo "${family.forms.adjective.word}" se transforma agregando el sufijo correspondiente para dar "${correctAnswer}".`;
          
          const others = pool.filter(p => p.id !== family.id && p.forms.adverb).map(p => p.forms.adverb!.word);
          options = shuffleArray([correctAnswer, ...others.slice(0, 3)]);
        } 
        else {
          // Fallback to translation question
          questionText = `¿Qué término describe correctamente al lexema raíz "${family.lexeme}" en español?`;
          correctAnswer = family.lexemeTranslation;
          explanation = `El lexema raíz "${family.lexeme}" se asocia directamente a la idea de "${correctAnswer}".`;
          
          const others = pool.filter(p => p.id !== family.id).map(p => p.lexemeTranslation);
          options = shuffleArray([correctAnswer, ...others.slice(0, 3)]);
        }
      } catch (err) {
        // Fallback translation if null fields hit
        questionText = `¿Qué significa el lexema "${family.lexeme}"?`;
        correctAnswer = family.lexemeTranslation;
        explanation = `El lexema "${family.lexeme}" se traduce como "${family.lexemeTranslation}".`;
        const others = pool.filter(p => p.id !== family.id).map(p => p.lexemeTranslation);
        options = shuffleArray([correctAnswer, ...others.slice(0, 3)]);
      }

      // Safeguard options length
      if (options.length < 4) {
        options = shuffleArray([correctAnswer, 'development', 'successful', 'quickly']);
      }

      quizList.push({
        id: `gen-${i}-${Date.now()}`,
        type,
        questionText,
        correctAnswer,
        explanation,
        options,
        wordFamilyId: family.id
      });
    }

    setQuestions(quizList);
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setIsAnswered(false);
    setCorrectCount(0);
    setQuizState('active');
  };

  const shuffleArray = (array: string[]) => {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  };

  const handleAnswerSubmit = (ans: string) => {
    if (isAnswered) return;
    if (timerRef.current) clearInterval(timerRef.current);
    
    setSelectedAnswer(ans);
    setIsAnswered(true);

    const activeQ = questions[currentIndex];
    if (ans === activeQ.correctAnswer) {
      setCorrectCount((prev) => prev + 1);
    }
  };

  const handleNext = () => {
    setSelectedAnswer(null);
    setIsAnswered(false);

    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Complete!
      setQuizState('completed');
      
      const cleanCategory = validateCategoryFilter(selectedCategory);
      const newStat: LocalQuizStats = {
        score: correctCount,
        total: questions.length,
        category: cleanCategory === 'todos' ? 'Temas Mezclados' : cleanCategory,
        date: new Date().toLocaleDateString('es-ES', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
      };

      const currentHistory = getSafeQuizHistory();
      const updated = [newStat, ...currentHistory].slice(0, 5); // list last 5 items
      saveSafeQuizHistory(updated);
      setHistory(updated);
    }
  };

  const clearHistory = () => {
    try {
      localStorage.removeItem('quiz_history');
      setHistory([]);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-50 text-slate-800 overflow-hidden">
      <AnimatePresence mode="wait">
        {quizState === 'setup' && (
          /* SETUP BOARD */
          <motion.div
            key="setup"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex-1 flex flex-col p-4 overflow-y-auto pb-8 gap-5"
          >
            {/* Branding introduction header */}
            <div className="text-center bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 text-blue-605 flex items-center justify-center mx-auto mb-2 text-xl select-none">
                🎯
              </div>
              <h3 className="text-sm font-bold text-slate-900">Quizzes Personalizados</h3>
              <p className="text-[11px] text-slate-500 italic">Forma tus propios tests para evaluar tu asimilación de patrones</p>
            </div>

            {/* Customization controls card */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col gap-4 shadow-sm">
              {/* Category Selector */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] text-slate-400 uppercase tracking-widest font-extrabold px-0.5">Categoría de vocabulario:</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-205 text-xs text-slate-800 rounded-xl focus:border-blue-600 focus:outline-none font-bold"
                >
                  <option value="todos">Mezclar todo el Vocabulario</option>
                  <option value="Éxito y Logro">🏆 Éxito y Logro</option>
                  <option value="Creación e Intelecto">🧠 Creación e Intelecto</option>
                  <option value="Acción e Interacción">⚡ Acción e Interacción</option>
                  <option value="Estado y Emoción">❤️ Estado y Emoción</option>
                </select>
              </div>

              {/* Number of exercises selector */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] text-slate-400 uppercase tracking-widest font-extrabold px-0.5">Número de preguntas:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[3, 5, 10].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setNumQuestions(num)}
                      className={`py-2 text-xs rounded-xl border font-bold cursor-pointer transition ${
                        numQuestions === num
                          ? 'bg-blue-600 border-blue-600 text-white font-extrabold shadow-sm'
                          : 'bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      {num} Preguntas
                    </button>
                  ))}
                </div>
              </div>

              {/* Timer control */}
              <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <div className="flex items-center gap-2">
                  <Timer className="w-5 h-5 text-blue-600" />
                  <div className="text-left">
                    <span className="text-xs text-slate-800 block font-bold">Temporizador de presión</span>
                    <span className="text-[10px] text-slate-500 block">20 segundos por reactivo</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setEnableTimer(!enableTimer)}
                  className={`w-11 h-6 rounded-full p-0.5 transition-colors cursor-pointer ${
                    enableTimer ? 'bg-blue-600' : 'bg-slate-300'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full shadow transition-transform ${
                      enableTimer ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Submit Trigger BUTTON */}
              <button
                onClick={generateQuiz}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-black rounded-xl uppercase tracking-wider transition-all shadow-sm cursor-pointer text-center select-none border border-blue-605/15"
              >
                Comenzar Quiz Evaluativo
              </button>
            </div>

            {/* Historical tracking scores card */}
            {history.length > 0 ? (
              <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col gap-3 shadow-xs">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs text-slate-805 uppercase tracking-wider font-extrabold flex items-center gap-1.5">
                    <History className="w-4 h-4 text-blue-600" />
                    Historial de Tests
                  </h4>
                  <button
                    onClick={clearHistory}
                    className="text-[9px] text-slate-400 hover:text-rose-600 font-bold uppercase transition"
                  >
                    Borrar Todo
                  </button>
                </div>

                <div className="flex flex-col gap-2">
                  {history.map((h, i) => (
                    <div
                      key={i}
                      className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                    >
                      <div className="text-left">
                        <span className="font-bold text-slate-700 block">{h.category}</span>
                        <span className="text-[9px] text-slate-450 block">{h.date}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-black font-mono text-blue-650 block">
                          {h.score} / {h.total}
                        </span>
                        <span className="text-[10px] text-slate-500 block font-semibold">
                          ({Math.round((h.score / h.total) * 100)}%)
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-4 bg-white rounded-xl border border-dashed border-slate-250 text-center text-slate-400 text-xs shadow-xs">
                Aún no has disputado ningún test evaluativo. Tus puntajes quedarán logueados aquí.
              </div>
            )}
          </motion.div>
        )}

        {quizState === 'active' && questions.length > 0 && (
          /* ACTIVE EXERCISE ROUND */
          <motion.div
            key="active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex-1 flex flex-col overflow-hidden"
          >
            {/* Header dashboard layout */}
            <div className="p-4 bg-white border-b border-slate-200 flex items-center justify-between select-none shadow-sm shrink-0">
              <div className="text-left">
                <span className="text-[10px] text-indigo-600 font-bold uppercase block">Quiz evaluativo</span>
                <span className="text-xs text-slate-900 font-mono font-black">
                  Pregunta {currentIndex + 1} de {questions.length}
                </span>
              </div>

              {/* Live Timer progress circles */}
              {enableTimer && (
                <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-mono font-bold ${
                  secondsLeft <= 5 
                    ? 'bg-rose-50 border-rose-200 text-rose-700 animate-pulse' 
                    : 'bg-amber-50 border border-amber-200 text-amber-700'
                }`}>
                  <Timer className="w-3.5 h-3.5" />
                  <span>{secondsLeft}s restante</span>
                </div>
              )}
            </div>

            {/* Quiz Body container */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 pb-8">
              <div className="bg-white rounded-2xl border border-slate-205 p-4.5 shadow-sm flex flex-col gap-4 relative">
                
                {/* Progress bar */}
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-blue-50 border border-blue-150 text-blue-600 font-mono font-extrabold w-max">
                  {questions[currentIndex].type.toUpperCase()}
                </span>

                <h4 className="text-sm font-bold text-slate-800 leading-relaxed font-sans">
                  {questions[currentIndex].questionText}
                </h4>

                {/* Answer choice list style */}
                <div className="flex flex-col gap-2 mt-1">
                  {questions[currentIndex].options.map((opt) => {
                    const isSelected = selectedAnswer === opt;
                    const isCorrectAnswer = opt === questions[currentIndex].correctAnswer;
                    
                    let btnStyle = 'bg-white border-slate-200 hover:border-slate-350 text-slate-700';
                    let iconSlot = <HelpCircle className="w-4 h-4 text-slate-400" />;

                    if (isSelected) {
                      btnStyle = 'border-blue-650 ring-1 ring-blue-650/15 bg-blue-50 border-[2px] text-blue-750 font-bold';
                    }

                    if (isAnswered) {
                      if (isCorrectAnswer) {
                        btnStyle = 'border-emerald-500 bg-emerald-50 text-emerald-805 border-[2px] font-black';
                        iconSlot = <Check className="w-4 h-4 text-emerald-600" />;
                      } else if (isSelected) {
                        btnStyle = 'border-rose-500 bg-rose-50 text-rose-805 border-[2px] font-bold';
                        iconSlot = <X className="w-4 h-4 text-rose-600" />;
                      } else {
                        btnStyle = 'bg-slate-50 border-slate-150 text-slate-400 opacity-55';
                        iconSlot = null;
                      }
                    }

                    return (
                      <button
                        key={opt}
                        onClick={() => handleAnswerSubmit(opt)}
                        disabled={isAnswered}
                        className={`p-3 text-xs rounded-xl border text-left transition-all flex items-center justify-between cursor-pointer ${btnStyle} select-none`}
                      >
                        <span className="truncate">{opt}</span>
                        {iconSlot}
                      </button>
                    );
                  })}
                </div>

                {/* Sub explanation panel on answered */}
                {isAnswered && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs flex flex-col gap-1 text-slate-600"
                  >
                    <span className="font-bold text-blue-600 flex items-center gap-1 block mb-0.5 select-none uppercase text-[10px]">
                      <ClipboardCheck className="w-4 h-4" />
                      Retroalimentación Didáctica:
                    </span>
                    <p className="leading-relaxed font-sans font-medium">
                      {selectedAnswer === '__timeout__' 
                        ? `⏱️ ¡Se acabó el tiempo de respuesta! ${questions[currentIndex].explanation}` 
                        : questions[currentIndex].explanation
                      }
                    </p>
                  </motion.div>
                )}
              </div>
            </div>

            {/* Bottom Actions for Quiz */}
            <div className="p-4 bg-white border-t border-slate-200 flex shrink-0 shadow-sm">
              {isAnswered && (
                <button
                  onClick={handleNext}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-black rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow border border-blue-650/10 select-none"
                >
                  {currentIndex + 1 === questions.length ? 'Finalizar Evaluación' : 'Continuar'}
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </motion.div>
        )}

        {quizState === 'completed' && (
          /* COMPLETION DISPLAY CARD */
          <motion.div
            key="completed"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex-1 p-4 flex flex-col justify-center items-center text-center pb-8"
          >
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm max-w-xs w-full flex flex-col gap-4.5">
              <div className="w-14 h-14 rounded-full bg-blue-50 border-2 border-blue-205 text-blue-600 flex items-center justify-center mx-auto text-2xl select-none animate-pulse">
                🏆
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900">¡Test Finalizado!</h3>
                <p className="text-[11px] text-slate-500 italic">Has completado el quiz bajo presión evaluativa.</p>
              </div>

              {/* Dynamic Score Panel */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4">
                <span className="text-[10px] text-slate-450 uppercase tracking-widest font-extrabold block animate-pulse">Puntuación Final</span>
                <span className="text-3xl font-black font-mono text-blue-650 block mt-1">
                  {correctCount} / {questions.length}
                </span>
                <span className="text-xs text-slate-500 font-bold block mt-0.5">
                  ({Math.round((correctCount / questions.length) * 100)}% correcto)
                </span>
              </div>

              {/* Performance feedback advice */}
              <p className="text-xs text-slate-650 leading-relaxed px-1 font-sans font-semibold">
                {correctCount === questions.length
                  ? '🏅 ¡Impecable! Rendimiento supremo del 100%. Has descifrado todas las ramificaciones con absoluta solvencia.'
                  : correctCount >= Math.floor(questions.length * 0.7)
                    ? '👍 ¡Buen trabajo! Posees un dominio robusto de las familias de palabras evaluadas.'
                    : '💡 ¡Sigue entrenando! Los quizzes son demandantes, te sugerimos seguir estudiando las reglas clave para robustecer tu acierto.'}
              </p>

              {/* Action buttons */}
              <button
                onClick={() => setQuizState('setup')}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow border border-blue-600/25 cursor-pointer select-none"
              >
                <RefreshCcw className="w-4 h-4" />
                <span>Configurar Nuevo Test</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
