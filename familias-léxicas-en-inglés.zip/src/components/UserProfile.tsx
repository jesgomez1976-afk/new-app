/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Mail, 
  User, 
  Check, 
  Share2, 
  Award, 
  Globe, 
  BookOpen, 
  GraduationCap, 
  LogOut, 
  RotateCcw,
  ShieldCheck
} from 'lucide-react';
import { getSafeSolvedExercises, getSafeQuizHistory } from '../utils/security';
import { LANGUAGES, LangCode, t } from '../utils/translator';

interface UserProfileProps {
  currentLanguage: LangCode;
  onLanguageChange: (lang: LangCode) => void;
  onRequestStatsRefresh?: () => void;
}

export default function UserProfile({ 
  currentLanguage, 
  onLanguageChange,
  onRequestStatsRefresh 
}: UserProfileProps) {
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [isSaved, setIsSaved] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  
  // Progress indicators
  const [solvedCount, setSolvedCount] = useState(0);
  const [quizCount, setQuizCount] = useState(0);
  const [shareSuccess, setShareSuccess] = useState(false);

  // Load profile state
  useEffect(() => {
    const savedEmail = localStorage.getItem('user_profile_email') || '';
    const savedName = localStorage.getItem('user_profile_name') || '';
    
    if (savedEmail) {
      setEmail(savedEmail);
      setUsername(savedName);
      setIsLoggedIn(true);
    }

    const solved = getSafeSolvedExercises();
    setSolvedCount(solved.length);

    const history = getSafeQuizHistory();
    setQuizCount(history.length);
  }, []);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Minimal validation to ensure safety
    const sanitizedEmail = email.trim().substring(0, 80);
    const sanitizedName = username.trim().substring(0, 40);

    if (sanitizedEmail) {
      // Validate secure email schema format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(sanitizedEmail)) {
        alert('Por favor ingrese un formato de correo electrónico válido.');
        return;
      }

      localStorage.setItem('user_profile_email', sanitizedEmail);
      localStorage.setItem('user_profile_name', sanitizedName || sanitizedEmail.split('@')[0]);
      setIsLoggedIn(true);
      setIsSaved(true);
      setTimeout(() => setIsSaved(false), 3000);
      
      if (onRequestStatsRefresh) {
        onRequestStatsRefresh();
      }
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('user_profile_email');
    localStorage.removeItem('user_profile_name');
    setEmail('');
    setUsername('');
    setIsLoggedIn(false);
    
    if (onRequestStatsRefresh) {
      onRequestStatsRefresh();
    }
  };

  const handleShare = async () => {
    const appUrl = window.location.href;
    const title = 'LexiBuild - Master English Word Families';
    const desc = 'Echa un vistazo a esta increíble app interactiva para expandir tu vocabulario en inglés dominando coeficientes y prefijos sistemáticamente!';

    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text: desc,
          url: appUrl,
        });
      } catch (err) {
        console.warn('Navigator native share failed or was cancelled:', err);
        fallbackCopyShare(appUrl);
      }
    } else {
      fallbackCopyShare(appUrl);
    }
  };

  const fallbackCopyShare = (url: string) => {
    try {
      navigator.clipboard.writeText(url);
      setShareSuccess(true);
      setTimeout(() => setShareSuccess(false), 3000);
    } catch (e) {
      console.error('Clipboard copy failed:', e);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-5 pb-8 bg-slate-50">
      {/* Visual Identity Section */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 text-center shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 p-3 text-blue-600">
          <ShieldCheck className="w-5 h-5 text-blue-600" />
        </div>
        
        {/* Profile Avatar Placeholder */}
        <div className="w-16 h-16 rounded-full bg-blue-50 border border-blue-150 text-blue-600 flex items-center justify-center mx-auto text-2xl font-bold mb-3 shadow-inner">
          {isLoggedIn ? (username ? username[0].toUpperCase() : 'U') : '👤'}
        </div>

        <h3 className="text-xl font-bold text-slate-900 tracking-tight leading-none mb-1">
          {isLoggedIn ? username : t('welcome', currentLanguage)}
        </h3>
        <p className="text-xs text-slate-500 italic">
          {isLoggedIn ? email : t('nonLoggedMsg', currentLanguage)}
        </p>

        {/* Share Button (Primary Focus UI Action) */}
        <div className="mt-4 flex justify-center">
          <button
            onClick={handleShare}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all shadow-sm active:scale-98"
          >
            <Share2 className="w-4 h-4" />
            <span>{t('shareApp', currentLanguage)}</span>
          </button>
        </div>

        {shareSuccess && (
          <motion.p
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-[10px] text-emerald-600 font-semibold mt-2.5"
          >
            {t('shareAppSuccess', currentLanguage)}
          </motion.p>
        )}
      </div>

      {/* Translations Language Options Selector Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col gap-3.5 shadow-sm">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-blue-600" />
          <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">
            {t('selectLanguage', currentLanguage)}
          </h4>
        </div>

        <div className="grid grid-cols-2 gap-2 mt-1">
          {LANGUAGES.map((lang) => (
            <button
              key={lang.code}
              onClick={() => onLanguageChange(lang.code)}
              className={`p-2.5 rounded-xl border flex items-center gap-2.5 text-xs font-bold cursor-pointer transition-all ${
                currentLanguage === lang.code
                  ? 'bg-blue-50 border-blue-400 text-blue-750'
                  : 'bg-slate-50 border-slate-150 text-slate-650 hover:bg-slate-100'
              }`}
            >
              <span className="text-sm select-none">{lang.flag}</span>
              <span>{lang.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Progress metrics and totals */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col gap-3.5 shadow-sm">
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-500" />
          <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">
            Progreso Acumulado
          </h4>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-1">
          <div className="bg-slate-50 border border-slate-150 p-3 rounded-xl">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-extrabold block">Ejercicios Fijos</span>
            <span className="text-lg font-black font-mono text-blue-600 mt-1 block">
              {solvedCount}
            </span>
            <span className="text-[9px] text-slate-500 font-bold block mt-0.5">Completados</span>
          </div>

          <div className="bg-slate-50 border border-slate-150 p-3 rounded-xl">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-extrabold block">Historial Quizzes</span>
            <span className="text-lg font-black font-mono text-indigo-600 mt-1 block">
              {quizCount}
            </span>
            <span className="text-[9px] text-slate-500 font-bold block mt-0.5">Disputados</span>
          </div>
        </div>
      </div>

      {/* Log-In Information Forms (Optional) */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col gap-3 shadow-sm">
        <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider mb-1 flex items-center gap-1.5">
          <User className="w-4 h-4 text-blue-600" />
          {isLoggedIn ? 'Datos de tu Cuenta' : 'Sincronizar Progreso (Opcional)'}
        </h4>

        {isLoggedIn ? (
          <div className="flex flex-col gap-3.5">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-155 text-xs flex flex-col gap-0.5">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wide">Usuario Activo:</span>
              <span className="font-bold text-slate-800">{username || 'Estudiante'}</span>
              <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wide mt-2">Email Asociado:</span>
              <span className="font-semibold text-slate-600 font-mono">{email}</span>
            </div>

            <button
              onClick={handleLogout}
              className="py-2.5 w-full bg-slate-105 hover:bg-slate-200 text-slate-650 rounded-xl text-xs font-bold border border-slate-200 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
            >
              <LogOut className="w-4 h-4" />
              <span>{t('logOut', currentLanguage)}</span>
            </button>
          </div>
        ) : (
          <form onSubmit={handleSaveProfile} className="flex flex-col gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 uppercase tracking-wide font-bold px-0.5">
                {t('emailOptional', currentLanguage)}
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  placeholder="ejemplo@correo.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-450 focus:outline-none focus:border-blue-605 transition-all font-sans font-medium"
                />
                <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-slate-500 uppercase tracking-wide font-bold px-0.5">
                Nombre de Usuario (Opcional)
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Tu Nombre o Apodo"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-450 focus:outline-none focus:border-blue-605 transition-all font-sans font-medium"
                  maxLength={30}
                />
                <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-750 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs border border-blue-605/10"
            >
              <Check className="w-4 h-4" />
              <span>{t('saveProfile', currentLanguage)}</span>
            </button>
          </form>
        )}

        {isSaved && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-2.5 bg-emerald-50 border border-emerald-250 text-emerald-700 text-center text-xs font-semibold rounded-xl"
          >
            {t('profileSaved', currentLanguage)}
          </motion.div>
        )}
      </div>
    </div>
  );
}
