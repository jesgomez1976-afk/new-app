/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { interactiveExercises } from '../data/exercises';
import { Exercise } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, AlertTriangle, ArrowRight, RotateCcw, Award, Lightbulb, Check, HelpCircle } from 'lucide-react';
import { getSafeSolvedExercises, saveSafeSolvedExercises, safeSpeech } from '../utils/security';

export default function InteractiveExercises() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [numCorrect, setNumCorrect] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [progressWidth, setProgressWidth] = useState(0);

  const activeExercise: Exercise = interactiveExercises[currentIndex];

  useEffect(() => {
    // Update progress bar width smoothly
    const percent = ((currentIndex) / interactiveExercises.length) * 100;
    setProgressWidth(percent);
  }, [currentIndex]);

  const handleOptionSelect = (option: string) => {
    if (isAnswered) return;
    setSelectedOption(option);
  };

  const handleCheckAnswer = () => {
    if (!selectedOption || isAnswered) return;
    
    setIsAnswered(true);
    if (selectedOption === activeExercise.correctAnswer) {
      setNumCorrect((prev) => prev + 1);
      // Save stats securely to localStorage with validation checks
      const solved = getSafeSolvedExercises();
      if (!solved.includes(activeExercise.id)) {
        solved.push(activeExercise.id);
        saveSafeSolvedExercises(solved);
      }
    }
  };

  const handleNext = () => {
    setSelectedOption(null);
    setIsAnswered(false);
    setShowExplanation(false);

    if (currentIndex + 1 < interactiveExercises.length) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setProgressWidth(100);
      setCompleted(true);
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setNumCorrect(0);
    setShowExplanation(false);
    setCompleted(false);
    setProgressWidth(0);
  };

  const speakText = (text: string) => {
    safeSpeech(text);
  };

  const renderBadge = (type: Exercise['type']) => {
    switch (type) {
      case 'fill-blank': return '📝 Rellenar Espacio';
      case 'suffix-drag': return '🧩 Unir Sufijo';
      case 'pos-match': return '🔄 Conversión Léxica';
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-50 text-slate-800 overflow-hidden relative">
      <AnimatePresence mode="wait">
        {!completed ? (
          /* ACTIVE EXERCISE VIEW */
          <motion.div
            key="practice-active"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex-1 flex flex-col overflow-hidden"
          >
            {/* Top Stat Dashboard Header */}
            <div className="p-4 bg-white border-b border-slate-200 flex flex-col gap-2.5 shrink-0 shadow-sm">
              <div className="flex justify-between items-center select-none">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Práctica Interactiva</h3>
                  <p className="text-[10px] text-slate-500">Preguntas fijas de asimilación gramatical</p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono font-bold text-blue-600">
                    {currentIndex + 1} de {interactiveExercises.length}
                  </span>
                  <span className="text-[10px] text-slate-400 block font-semibold">Progreso</span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-blue-650 rounded-full"
                  animate={{ width: `${progressWidth}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>

            {/* Scrollable Main body */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 pb-8">
              {/* Question card container */}
              <motion.div 
                key={activeExercise.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white border border-slate-205 rounded-2xl p-4 shadow-sm flex flex-col gap-3 relative"
              >
                <div className="flex justify-between items-center">
                  <span className="text-[9px] font-extrabold uppercase tracking-widest px-2 py-0.5 rounded-lg bg-blue-50 text-blue-700 border border-blue-105">
                    {renderBadge(activeExercise.type)}
                  </span>
                  {activeExercise.targetWord && (
                    <span className="text-[10px] text-slate-450 font-semibold">
                      Raíz: <span className="font-mono font-bold text-slate-900 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">{activeExercise.targetWord}</span>
                    </span>
                  )}
                </div>

                <h4 className="text-xs font-bold text-slate-800 leading-relaxed font-sans">
                  {activeExercise.instruction}
                </h4>

                {/* Optional sentence context for fill-in-the-blank */}
                {activeExercise.sentenceContext && (
                  <div className="my-2.5 p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-center">
                    <p className="text-xs font-semibold text-slate-800 leading-relaxed font-sans">
                      {activeExercise.sentenceContext.split('_______').map((part, index, arr) => (
                        <React.Fragment key={index}>
                          {part}
                          {index < arr.length - 1 && (
                            <span className={`px-2.5 py-0.5 rounded border font-bold text-xs tracking-wide mx-1 inline-block min-w-16 ${
                              isAnswered 
                                ? selectedOption === activeExercise.correctAnswer 
                                  ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
                                  : 'bg-rose-50 border-rose-300 text-rose-700'
                                : 'bg-white border-dashed border-slate-300 text-blue-600'
                            }`}>
                              {selectedOption ? selectedOption : '______'}
                            </span>
                          )}
                        </React.Fragment>
                      ))}
                    </p>
                  </div>
                )}

                {/* Option Chips Choices Grid */}
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {activeExercise.options.map((opt) => {
                    const isSelected = selectedOption === opt;
                    const isCorrect = opt === activeExercise.correctAnswer;
                    
                    let bgStyle = 'bg-white border-slate-200 hover:border-slate-350 text-slate-700';
                    if (isSelected) {
                      bgStyle = 'border-blue-650 ring-1 ring-blue-650/15 bg-blue-50 border-[2px] text-blue-750 font-bold';
                    }
                    if (isAnswered) {
                      if (isCorrect) {
                        bgStyle = 'border-emerald-500 bg-emerald-50 text-emerald-805 border-[2px] font-black';
                      } else if (isSelected) {
                        bgStyle = 'border-rose-500 bg-rose-50 text-rose-805 border-[2px] font-bold';
                      } else {
                        bgStyle = 'bg-slate-50 border-slate-150 text-slate-400 opacity-60';
                      }
                    }

                    return (
                      <button
                        key={opt}
                        onClick={() => handleOptionSelect(opt)}
                        disabled={isAnswered}
                        className={`p-3 text-xs rounded-xl border text-center transition-all cursor-pointer font-bold select-none ${bgStyle} truncate`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>

                {/* Interactive Status Indicator bar */}
                {isAnswered && (
                  <motion.div
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className={`p-3.5 rounded-xl border flex items-start gap-2.5 mt-2 ${
                      selectedOption === activeExercise.correctAnswer
                        ? 'bg-emerald-100/10 border-emerald-250 text-emerald-800'
                        : 'bg-rose-100/10 border-rose-250 text-rose-800'
                    }`}
                  >
                    {selectedOption === activeExercise.correctAnswer ? (
                      <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600 mt-0.5" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 shrink-0 text-rose-600 mt-0.5" />
                    )}
                    <div>
                      <span className="font-extrabold text-xs select-none block">
                        {selectedOption === activeExercise.correctAnswer ? '¡Excelente Trabajo!' : 'Incorrecto, inténtalo de nuevo'}
                      </span>
                      <p className="text-[11px] text-slate-600 leading-relaxed mt-0.5 font-sans font-semibold">
                        {activeExercise.explanation}
                      </p>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            </div>

            {/* Bottom Actions Floating Bar */}
            <div className="p-4 bg-white border-t border-slate-200 flex gap-3 shrink-0 shadow-sm">
              {!isAnswered ? (
                <button
                  onClick={handleCheckAnswer}
                  disabled={!selectedOption}
                  className={`flex-1 py-3 text-xs font-bold rounded-xl transition-all border shadow-sm cursor-pointer select-none ${
                    selectedOption
                      ? 'bg-blue-600 border-blue-600 text-white font-extrabold hover:bg-blue-700'
                      : 'bg-slate-100 border-slate-200 text-slate-400 shadow-none cursor-not-allowed'
                  }`}
                >
                  Confirmar Respuesta
                </button>
              ) : (
                <button
                  onClick={handleNext}
                  className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 border border-blue-600 text-white text-xs font-extrabold rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-sm cursor-pointer select-none"
                >
                  <span>Siguiente Pregunta</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </motion.div>
        ) : (
          /* COMPLETION VIEW */
          <motion.div
            key="practice-completed"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex-1 p-4 flex flex-col justify-center items-center text-center pb-8"
          >
            <div className="bg-white border border-slate-200 rounded-2xl p-6.5 shadow-sm max-w-xs w-full flex flex-col gap-4">
              <div className="inline-flex p-3 rounded-full bg-blue-50 border border-blue-250 text-blue-605 mx-auto select-none">
                <Award className="w-10 h-10 animate-bounce" />
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900 px-2">¡Práctica Completada!</h3>
                <p className="text-xs text-slate-500 italic mt-0.5">Has terminado los ejercicios fijos con éxito.</p>
              </div>

              {/* Score Circular visualization */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest font-extrabold block">Aciertos Obtenidos</span>
                <div className="text-3xl font-black font-mono text-blue-650 mt-1">
                  {numCorrect} / {interactiveExercises.length}
                </div>
                <div className="text-xs font-bold text-slate-500 mt-1">
                  ({Math.round((numCorrect / interactiveExercises.length) * 100)}% de efectividad)
                </div>
              </div>

              {/* Level advice / diagnostic */}
              <p className="text-xs text-slate-650 leading-relaxed px-1 font-sans font-semibold">
                {numCorrect >= 8
                  ? '🏆 ¡Magnífico! Tienes un excelente control de la transformación gramatical. Te sugerimos pasar a los desafíos de los Quizzes personalizados.'
                  : '📈 ¡Buen progreso! Te sugerimos repasar la pestaña de **Reglas Maestras** y volver a intentar para conseguir un porcentaje de nivel óptimo.'}
              </p>

              {/* Actions */}
              <button
                onClick={handleRestart}
                className="py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-xl shadow cursor-pointer transition flex items-center justify-center gap-1.5 border border-blue-600/30"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reiniciar Práctica</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
