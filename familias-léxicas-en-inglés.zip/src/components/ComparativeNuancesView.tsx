/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from 'react';
import { comparativeTables, ComparativeGroup, ComparativeWord } from '../data/comparativeTables';
import { motion, AnimatePresence } from 'motion/react';
import { Layers, HelpCircle, Volume2, Search, SlidersHorizontal, ArrowRight, Quote } from 'lucide-react';
import { safeSpeech } from '../utils/security';
import { LangCode, t } from '../utils/translator';

interface ComparativeNuancesViewProps {
  currentLanguage: LangCode;
}

export default function ComparativeNuancesView({ currentLanguage }: ComparativeNuancesViewProps) {
  const [activeGroupId, setActiveGroupId] = useState<string>(comparativeTables[0].id);
  const [searchTerm, setSearchTerm] = useState('');

  const activeGroup = comparativeTables.find(g => g.id === activeGroupId) || comparativeTables[0];

  const handleSpeak = (text: string) => {
    safeSpeech(text);
  };

  const filteredGroups = comparativeTables.filter(group => {
    const searchLower = searchTerm.toLowerCase();
    const titleMatches = group.title.toLowerCase().includes(searchLower);
    const categoryMatches = (group.categoryTranslations[currentLanguage] || group.category).toLowerCase().includes(searchLower);
    const subcategoryMatches = (group.subcategoryTranslations[currentLanguage] || group.subcategory).toLowerCase().includes(searchLower);
    const wordMatches = group.words.some(w => 
      w.word.toLowerCase().includes(searchLower) || 
      w.meaning.toLowerCase().includes(searchLower) ||
      (w.meaningTranslations[currentLanguage] || '').toLowerCase().includes(searchLower)
    );
    return titleMatches || categoryMatches || subcategoryMatches || wordMatches;
  });

  const getTranslatedCategory = (group: ComparativeGroup) => {
    return group.categoryTranslations[currentLanguage] || group.category;
  };

  const getTranslatedSubcategory = (group: ComparativeGroup) => {
    return group.subcategoryTranslations[currentLanguage] || group.subcategory;
  };

  const getTranslatedDescription = (group: ComparativeGroup) => {
    return group.descriptionTranslations[currentLanguage] || group.description;
  };

  const getTranslatedWordMeaning = (wd: ComparativeWord) => {
    return wd.meaningTranslations[currentLanguage] || wd.meaning;
  };

  const getTranslatedWordContexts = (wd: ComparativeWord) => {
    return wd.bestContextsTranslations[currentLanguage] || wd.bestContexts;
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-50 text-slate-800 overflow-hidden">
      {/* Top filter section with search and dynamic slide selectors */}
      <div className="p-4 bg-white border-b border-slate-205 flex flex-col gap-3 shrink-0 shadow-sm">
        <div>
          <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Layers className="w-5 h-5 text-blue-600 animate-pulse" />
            {t('comparativeNuances', currentLanguage)}
          </h2>
          <p className="text-[11px] text-slate-500">{t('nuanceTablesDesc', currentLanguage)}</p>
        </div>

        {/* Word comparison search input */}
        <div className="relative">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar palabras delicadas, matices..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white transition-all font-sans"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-650"
            >
              ✕
            </button>
          )}
        </div>

        {/* Horizontal word list selectors */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none select-none">
          {filteredGroups.map((group) => (
            <button
              key={group.id}
              onClick={() => setActiveGroupId(group.id)}
              className={`px-3 py-1.5 text-[10px] uppercase font-bold tracking-wider rounded-lg border shrink-0 transition-all cursor-pointer ${
                activeGroupId === group.id
                  ? 'bg-blue-600 border-blue-605 text-white font-black shadow-xs'
                  : 'bg-slate-50 border-slate-200 text-slate-500 hover:border-slate-350 hover:text-slate-700'
              }`}
            >
              {group.title}
            </button>
          ))}
        </div>
      </div>

      {/* Main comparative table board scroll container */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 pb-8">
        <AnimatePresence mode="wait">
          {activeGroup ? (
            <motion.div
              key={activeGroup.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="flex flex-col gap-4"
            >
              {/* Category tags and description header */}
              <div className="bg-white border border-slate-250/70 p-4.5 rounded-2xl shadow-[0_1px_2px_rgba(0,0,0,0.015)] relative overflow-hidden">
                <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                  <span className="text-[9px] px-2 py-0.5 rounded-md bg-blue-50 border border-blue-150 text-blue-600 uppercase font-black tracking-widest leading-none">
                    {getTranslatedCategory(activeGroup)}
                  </span>
                  <span className="text-slate-300 select-none">•</span>
                  <span className="text-[10px] text-indigo-600 font-extrabold uppercase font-mono tracking-wider">
                    {getTranslatedSubcategory(activeGroup)}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 mt-1 uppercase tracking-tight">
                  {t('comparativeTitle', currentLanguage)} <span className="text-blue-600 italic font-medium font-sans">{activeGroup.title}</span>
                </h3>
                <p className="text-[11px] text-slate-500 leading-relaxed italic mt-1.5">
                  "{getTranslatedDescription(activeGroup)}"
                </p>
              </div>

              {/* Comparative Table Layout (Optimized for Mobile with gorgeous typography mimicking Screenshot 2) */}
              <div className="bg-[#FAF8F5] border border-orange-100 rounded-3xl p-1 shadow-sm overflow-hidden flex flex-col">
                {/* Header row */}
                <div className="grid grid-cols-12 bg-[#F5EFE6] border-b border-orange-100/50 p-3 text-[10px] uppercase tracking-wider font-extrabold text-[#7C5A37] select-none rounded-t-2xl font-mono text-center gap-1">
                  <div className="col-span-3 text-left pl-1">Word</div>
                  <div className="col-span-5">{t('nuanceMeaning', currentLanguage)}</div>
                  <div className="col-span-4">{t('bestContexts', currentLanguage)}</div>
                </div>

                {/* Table rows list */}
                <div className="flex flex-col divide-y divide-[#EFE7DC]">
                  {activeGroup.words.map((wd, i) => (
                    <div 
                      key={wd.word} 
                      className="flex flex-col p-4.5 bg-[#FAF8F5] gap-3"
                    >
                      {/* Primary comparative record row */}
                      <div className="grid grid-cols-12 gap-1.5 items-start">
                        {/* Huge stylized word */}
                        <div className="col-span-3 flex items-center gap-1">
                          <button 
                            onClick={() => handleSpeak(wd.word)}
                            className="p-1 px-1.5 bg-[#F4ECDE] hover:bg-[#EAE0CD] text-[#7C5A37] rounded-lg transition-colors cursor-pointer mr-1"
                            title="Pronunciar"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                          <span className="text-xs font-black text-slate-900 font-sans tracking-tight">
                            {wd.word}
                          </span>
                        </div>

                        {/* Band 9 meaning nuance */}
                        <div className="col-span-5 text-[11px] text-slate-750 font-sans font-medium pr-1 checked-out-meaning">
                          {getTranslatedWordMeaning(wd)}
                        </div>

                        {/* Best sub contexts */}
                        <div className="col-span-4 text-[10px] text-[#7C5A37] font-semibold bg-[#F4ECDE]/40 rounded-lg p-1.5 text-center font-sans tracking-tight">
                          {getTranslatedWordContexts(wd)}
                        </div>
                      </div>

                      {/* Accentuated Example (Band 9 sentence) */}
                      <div className="bg-white/80 border border-[#E9E1D2] rounded-2xl p-3 flex flex-col gap-1.5 relative overflow-hidden shadow-xs mt-1">
                        <div className="absolute right-2.5 top-2.5 text-[#E6DCBF] pointer-events-none">
                          <Quote className="w-6 h-6 rotate-180" />
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[9px] px-1.5 py-0.5 rounded-md bg-[#FAF8F5] border border-[#E5DBBE] font-bold text-[#7C5A37] font-mono leading-none uppercase select-none">
                            Example (Band 9)
                          </span>
                          <button 
                            onClick={() => handleSpeak(wd.example)}
                            className="p-0.5 text-slate-400 hover:text-blue-600 transition-colors"
                          >
                            <Volume2 className="w-3" />
                          </button>
                        </div>
                        <p className="text-[11px] text-slate-900 leading-relaxed italic pr-4 font-sans font-semibold">
                          "{wd.example}"
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-400">
              <SlidersHorizontal className="w-10 h-10 mb-2 text-slate-300" />
              <p className="text-sm font-semibold text-slate-700">{t('noResults', currentLanguage)}</p>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
