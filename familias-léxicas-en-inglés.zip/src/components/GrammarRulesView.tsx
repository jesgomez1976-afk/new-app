/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { grammarRules, goldRules } from '../data/grammarRules';
import { HelpCircle, ChevronDown, ChevronUp, Star, Award, Sparkles, BookOpen, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function GrammarRulesView() {
  const [activeTab, setActiveTab] = useState<'rules' | 'gold'>('rules');
  const [expandedSection, setExpandedSection] = useState<string | null>('verb-to-noun');

  const toggleSection = (id: string) => {
    setExpandedSection(expandedSection === id ? null : id);
  };

  const getSectionColor = (id: string) => {
    switch (id) {
      case 'verb-to-noun': return 'border-l-rose-500';
      case 'noun-to-adj': return 'border-l-indigo-500';
      case 'adj-to-adv': return 'border-l-amber-500';
      default: return 'border-l-slate-700';
    }
  };

  const getTagStyle = (id: string) => {
    switch (id) {
      case 'verb-to-noun': return 'bg-rose-500/10 text-rose-300 border-rose-500/20';
      case 'noun-to-adj': return 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20';
      case 'adj-to-adv': return 'bg-amber-500/10 text-amber-300 border-amber-500/20';
      default: return 'bg-slate-800 text-slate-350 border-slate-700';
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-50 text-slate-800 overflow-hidden">
      {/* Secondary Top Tabs */}
      <div className="p-3 bg-white border-b border-slate-200 flex gap-2 select-none shrink-0 shadow-sm">
        <button
          onClick={() => setActiveTab('rules')}
          className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 border cursor-pointer ${
            activeTab === 'rules'
              ? 'bg-blue-50 border-blue-200/80 text-blue-750 font-extrabold shadow-sm'
              : 'bg-slate-50 border-slate-150 text-slate-450 hover:text-slate-700'
          }`}
        >
          <FileText className="w-3.5 h-3.5 text-blue-600" />
          <span>Reglas Maestras</span>
        </button>
        <button
          onClick={() => setActiveTab('gold')}
          className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 border cursor-pointer ${
            activeTab === 'gold'
              ? 'bg-amber-50 border-amber-200/80 text-amber-700 font-extrabold shadow-sm'
              : 'bg-slate-50 border-slate-150 text-slate-450 hover:text-slate-700'
          }`}
        >
          <Star className="w-3.5 h-3.5 text-amber-500" />
          <span>Método de Oro</span>
        </button>
      </div>

      {/* Main Container */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 pb-8">
        <AnimatePresence mode="wait">
          {activeTab === 'rules' ? (
            /* Rules Section */
            <motion.div
              key="rules-list"
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="flex flex-col gap-4"
            >
              <div className="flex items-center gap-2 px-1 mb-1">
                <BookOpen className="w-5 h-5 text-blue-600" />
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Guía Sistemática de Suffixes</h3>
                  <p className="text-[10px] text-slate-500">Toca cada módulo para ver sus patrones y excepciones clave</p>
                </div>
              </div>

              {grammarRules.map((sec) => {
                const isExpanded = expandedSection === sec.id;
                return (
                  <div
                    key={sec.id}
                    className={`bg-white border border-slate-200 rounded-2xl overflow-hidden transition-all border-l-4 ${getSectionColor(sec.id)} shadow-sm`}
                  >
                    {/* Header trigger */}
                    <div
                      onClick={() => toggleSection(sec.id)}
                      className="p-3.5 cursor-pointer flex items-center justify-between select-none hover:bg-slate-50/50"
                    >
                      <div className="flex-1 pr-3">
                        <h4 className="text-sm font-bold text-slate-900">{sec.title}</h4>
                        <p className="text-[10px] text-slate-500 italic font-semibold">{sec.subtitle}</p>
                      </div>
                      <div className="text-slate-500 p-1 rounded-lg bg-slate-50 border border-slate-205">
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </div>
                    </div>

                    {/* Animated Collapsible details */}
                    <AnimatePresence initial={false}>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="border-t border-slate-100 overflow-hidden"
                        >
                          <div className="p-3.5 flex flex-col gap-3 bg-white">
                            <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-2.5 rounded-xl border border-slate-150">
                              {sec.generalRule}
                            </p>

                            {/* Rule Patterns Table */}
                            <div className="flex flex-col gap-2 mt-1 font-sans">
                              <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-400 px-1">
                                Patrones Comunes
                              </span>

                              <div className="flex flex-col gap-1.5">
                                {sec.patterns.map((pat, idx) => (
                                  <div
                                    key={idx}
                                    className="p-2.5 bg-slate-50/50 rounded-xl border border-slate-200 flex flex-col gap-1 text-xs"
                                  >
                                    <div className="flex items-center justify-between">
                                      <span className="text-blue-600 font-extrabold text-[12px] font-mono">
                                        {pat.suffix}
                                      </span>
                                      <span className="text-[10px] font-sans text-slate-500 text-right italic font-medium">
                                        {pat.rule}
                                      </span>
                                    </div>
                                    <div className="flex items-center justify-between mt-1 text-[11px] text-slate-600 border-t border-slate-100 pt-1.5 font-sans">
                                      <span className="text-slate-450">{pat.example}</span>
                                      <span className="text-slate-900 font-bold">{pat.process}</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Section Irregularities Exception alert block */}
                            {sec.keySecret && sec.keySecretDetail && (
                              <div className="mt-2.5 p-3 rounded-xl border border-amber-205 bg-amber-50/50 flex flex-col gap-1.5">
                                <div className="flex items-center gap-1.5 text-amber-700 text-xs font-bold">
                                  <Sparkles className="w-4 h-4 shrink-0 text-amber-500 animate-pulse" />
                                  <span>{sec.keySecret}</span>
                                </div>
                                <div className="text-[11px] text-slate-600 leading-relaxed flex flex-col gap-1 font-sans font-medium">
                                  {sec.keySecretDetail.map((line, idx) => (
                                    <span key={idx}>{line}</span>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </motion.div>
          ) : (
            /* Golden Steps View */
            <motion.div
              key="gold-section"
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col gap-4 shadow-sm"
            >
              <div className="text-center pb-2 border-b border-slate-100">
                <div className="inline-flex p-2 rounded-full bg-amber-50 text-amber-600 border border-amber-200/60 mb-1.5">
                  <Award className="w-6 h-6 animate-spin-slow" />
                </div>
                <h3 className="text-base font-bold text-slate-900">{goldRules.title}</h3>
                <p className="text-[11px] text-slate-500 italic">La guía más rápida para dominar la formación léxica</p>
              </div>

              <div className="flex flex-col gap-4">
                {goldRules.steps.map((step) => (
                  <div
                    key={step.num}
                    className="flex gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200 items-start hover:border-slate-300 transition-all"
                  >
                    <div className="w-6 h-6 shrink-0 rounded-full bg-amber-400 font-bold text-slate-900 flex items-center justify-center text-xs shadow-sm select-none">
                      {step.num}
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                        {step.action}
                      </h4>
                      <p className="text-xs text-slate-600 whitespace-pre-line leading-relaxed font-sans font-medium">
                        {step.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Extra Encouraging banner */}
              <div className="bg-blue-50/50 border border-blue-200/50 rounded-xl p-3.5 text-center mt-1">
                <span className="text-[10px] text-blue-600 font-bold uppercase tracking-wider block mb-0.5">💡 Consejo de Estudio</span>
                <p className="text-[11px] text-slate-650 leading-relaxed font-sans">
                  Intenta practicar con 5 palabras diarias en la sección de **Ejercicios**. La repetición espaciada fijará los sufijos para siempre.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
