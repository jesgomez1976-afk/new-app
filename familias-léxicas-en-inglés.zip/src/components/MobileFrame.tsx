/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Smartphone, Laptop, Sparkles, Wifi, Battery, ShieldAlert, Cpu } from 'lucide-react';

interface MobileFrameProps {
  children: React.ReactNode;
}

export default function MobileFrame({ children }: MobileFrameProps) {
  const [os, setOs] = useState<'apple' | 'android'>('apple');
  const [time, setTime] = useState('07:56');
  const [battery, setBattery] = useState(88);

  // Simple clock effect to keep the system status bar live
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getUTCHours().toString().padStart(2, '0');
      let minutes = now.getUTCMinutes().toString().padStart(2, '0');
      setTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-slate-100 py-6 px-4 flex flex-col items-center justify-center font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Controls: OS Switcher & Info */}
      <div className="w-full max-w-sm mb-4 flex justify-between items-center bg-white p-2 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
          <Cpu className="w-4 h-4 text-blue-600 animate-pulse" />
          <span>Vista Simulada:</span>
        </div>
        <div className="flex gap-1.5">
          <button
            onClick={() => setOs('apple')}
            className={`px-3 py-1 text-xs rounded-lg font-semibold transition-all flex items-center gap-1 cursor-pointer ${
              os === 'apple'
                ? 'bg-blue-600 text-white shadow'
                : 'bg-slate-100 text-slate-500 hover:text-slate-700'
            }`}
          >
            🍎 Apple iOS
          </button>
          <button
            onClick={() => setOs('android')}
            className={`px-3 py-1 text-xs rounded-lg font-semibold transition-all flex items-center gap-1 cursor-pointer ${
              os === 'android'
                ? 'bg-amber-500 text-slate-900 shadow font-bold'
                : 'bg-slate-100 text-slate-500 hover:text-slate-700'
            }`}
          >
            🤖 Android OS
          </button>
        </div>
      </div>

      {/* Main Chassis Device */}
      <div
        id="device-chassis"
        className={`relative w-full max-w-[390px] h-[780px] bg-slate-900 rounded-[48px] p-3 shadow-2xl transition-all duration-300 ring-12 ${
          os === 'apple'
            ? 'ring-slate-800 border-2 border-slate-750'
            : 'ring-blue-900/15 border-2 border-slate-800'
        } flex flex-col overflow-hidden`}
      >
        {/* Device Features */}
        {/* Apple Dynamic Island / Android Punch-hole */}
        {os === 'apple' ? (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-2xl z-50 flex items-center justify-center border border-slate-850 shadow-inner">
            <div className="w-2.5 h-2.5 bg-slate-900 rounded-full absolute right-3 border border-slate-950"></div>
          </div>
        ) : (
          <div className="absolute top-5 left-1/2 -translate-x-1/2 w-4 h-4 bg-black rounded-full z-50 flex items-center justify-center border border-slate-850 shadow-inner">
            <div className="w-1.5 h-1.5 bg-slate-900 rounded-full"></div>
          </div>
        )}

        {/* Device Status Bar */}
        <div className="h-10 px-5 pt-2 flex justify-between items-center text-xs font-semibold select-none z-40 bg-white/95 backdrop-blur border-b border-rose-100/10 text-slate-700">
          <div>{time}</div>
          <div className="flex items-center gap-1.5 pt-1">
            <Wifi className="w-3.5 h-3.5 text-slate-650" />
            <span className="text-[10px] bg-slate-100 px-1 rounded text-slate-500">5G</span>
            <div className="flex items-center gap-0.5">
              <span className="text-[10px] text-slate-500">{battery}%</span>
              <Battery className="w-4 h-4 text-emerald-555" />
            </div>
          </div>
        </div>

        {/* Actual App Frame Content */}
        <div className="flex-1 bg-slate-50 rounded-[36px] overflow-hidden flex flex-col relative">
          {children}
        </div>

        {/* Bottom Platform Indicators */}
        {os === 'apple' ? (
          <div className="h-6 w-full flex items-center justify-center z-40 bg-white pt-1 select-none border-t border-slate-100">
            <div className="w-32 h-1.5 bg-slate-300 rounded-full"></div>
          </div>
        ) : (
          <div className="h-8 w-full flex items-center justify-around z-40 bg-white pt-1 select-none text-slate-400 font-bold border-t border-slate-100">
            <span className="text-sm">◀</span>
            <span className="text-sm">●</span>
            <span className="text-xs">■</span>
          </div>
        )}
      </div>

      {/* Info Footnote */}
      <p className="mt-4 text-[11px] text-slate-400 text-center max-w-sm">
        Disfruta de la experiencia móvil híbrida. Cambia de sistema operativo con los botones superiores para previsualizar los acabados de diseño.
      </p>
    </div>
  );
}
