/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { WordFamily } from '../types';
import { wordFamilies } from '../data/wordFamilies';
import WordFamilyTree from './WordFamilyTree';
import { Search, SlidersHorizontal, BookOpen, Layers, Smile, Shuffle, ArrowLeft, ArrowRight, HeartPulse } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { LangCode, t, getTranslatedWord, getTranslatedDefinition, translateCategoryName } from '../utils/translator';

interface VocabularyExplorerProps {
  currentLanguage: LangCode;
}

export default function VocabularyExplorer({ currentLanguage }: VocabularyExplorerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [selectedFamilyId, setSelectedFamilyId] = useState<string | null>(null);

  const categories = ['todos', 'Éxito y Logro', 'Creación e Intelecto', 'Acción e Interacción', 'Estado y Emoción'];

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  // Filter word families
  const filteredFamilies = wordFamilies.filter((fam) => {
    const matchesCategory = selectedCategory === 'todos' || fam.category === selectedCategory;
    
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = 
      fam.lexeme.toLowerCase().includes(searchLower) ||
      fam.lexemeTranslation.toLowerCase().includes(searchLower) ||
      (fam.forms.verb?.word.toLowerCase().includes(searchLower) ?? false) ||
      (fam.forms.noun?.word.toLowerCase().includes(searchLower) ?? false) ||
      (fam.forms.adjective?.word.toLowerCase().includes(searchLower) ?? false) ||
      (fam.forms.adverb?.word.toLowerCase().includes(searchLower) ?? false);

    return matchesCategory && matchesSearch;
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Éxito y Logro': return '🏆';
      case 'Creación e Intelecto': return '🧠';
      case 'Acción e Interacción': return '⚡';
      case 'Estado y Emoción': return '❤️';
      default: return '📖';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Éxito y Logro': return 'bg-emerald-50 border-emerald-250 text-emerald-700';
      case 'Creación e Intelecto': return 'bg-indigo-50 border-indigo-250 text-indigo-700';
      case 'Acción e Interacción': return 'bg-sky-50 border-sky-250 text-sky-700';
      case 'Estado y Emoción': return 'bg-rose-50 border-rose-250 text-rose-700';
      default: return 'bg-slate-50 border-slate-200 text-slate-500';
    }
  };

  // Selected Family Detailed View
  const activeFamily = wordFamilies.find((f) => f.id === selectedFamilyId);

  // Load a random family
  const handleRandomFamily = () => {
    const randomIndex = Math.floor(Math.random() * wordFamilies.length);
    setSelectedFamilyId(wordFamilies[randomIndex].id);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-50 text-slate-800 overflow-hidden">
      <AnimatePresence mode="wait">
        {!selectedFamilyId ? (
          /* List Mode */
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex-1 flex flex-col overflow-hidden"
          >
            {/* Header section with branding and search */}
            <div className="p-4 bg-white border-b border-slate-200 flex flex-col gap-3 shrink-0">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
                    <BookOpen className="w-5 h-5 text-blue-600" />
                    {t('lexicalSearcher', currentLanguage)}
                  </h2>
                  <p className="text-[11px] text-slate-500">{t('lexicalSearcherDesc', currentLanguage)}</p>
                </div>
                <button
                  onClick={handleRandomFamily}
                  className="p-2 bg-slate-50 hover:bg-slate-100 text-blue-600 rounded-xl border border-slate-200 flex items-center gap-1.5 text-xs font-semibold cursor-pointer transition-all shadow-sm"
                  title="Raíz aleatoria"
                >
                  <Shuffle className="w-3.5 h-3.5" />
                  <span>{t('surpriseMe', currentLanguage)}</span>
                </button>
              </div>

              {/* Styled input search box */}
              <div className="relative">
                <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-450" />
                <input
                  type="text"
                  placeholder={t('searchPlaceholder', currentLanguage)}
                  value={searchTerm}
                  onChange={handleSearchChange}
                  className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-650 focus:bg-white focus:ring-1 focus:ring-blue-650/15 transition-all font-sans"
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm('')}
                    className="absolute right-3 top-2.5 text-xs text-slate-440 hover:text-slate-650"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Horizontal sliding categories filter chips */}
              <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none select-none">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 text-[10px] uppercase tracking-wider font-semibold rounded-lg border shrink-0 transition-all cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-blue-600 border-blue-600 text-white shadow-sm font-black'
                        : 'bg-slate-50 border-slate-150 text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    {cat === 'todos' ? t('allTopics', currentLanguage) : `${getCategoryIcon(cat)} ${translateCategoryName(cat, currentLanguage)}`}
                  </button>
                ))}
              </div>
            </div>

            {/* Scrollable grid listing results */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 bg-slate-50/50">
              {filteredFamilies.length > 0 ? (
                filteredFamilies.map((fam) => (
                  <motion.div
                    key={fam.id}
                    layoutId={`family-card-${fam.id}`}
                    onClick={() => setSelectedFamilyId(fam.id)}
                    className="bg-white hover:bg-slate-50/30 border border-slate-200 p-4 rounded-2xl cursor-pointer transition-all flex flex-col gap-2.5 relative overflow-hidden group select-none shadow-[0_1px_2px_rgba(0,0,0,0.02)] hover:shadow-sm"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="text-lg font-bold text-slate-900 tracking-tight">
                          {fam.lexeme}
                        </span>
                        <span className="text-xs text-slate-500 italic">
                          ({fam.lexemeTranslation})
                        </span>
                      </div>
                      <span className={`text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider font-bold border ${getCategoryColor(fam.category)}`}>
                        {fam.category}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-600 line-clamp-1 italic">
                      "{fam.lexemeDefinition}"
                    </p>

                    {/* Compact Forms Preview Badges */}
                    <div className="flex flex-wrap gap-1.5 mt-1 border-t border-slate-100 pt-2.5">
                      {fam.forms.verb && (
                        <span className="text-[10px] bg-rose-50/50 text-rose-700 border border-rose-100/50 px-2 py-0.5 rounded font-mono">
                          v: <span className="font-bold">{fam.forms.verb.word}</span>
                        </span>
                      )}
                      {fam.forms.noun && (
                        <span className="text-[10px] bg-teal-50/50 text-teal-700 border border-teal-100/50 px-2 py-0.5 rounded font-mono">
                          n: <span className="font-bold">{fam.forms.noun.word}</span>
                        </span>
                      )}
                      {fam.forms.adjective && (
                        <span className="text-[10px] bg-indigo-50/50 text-indigo-700 border border-indigo-100/50 px-2 py-0.5 rounded font-mono">
                          adj: <span className="font-bold">{fam.forms.adjective.word}</span>
                        </span>
                      )}
                      {fam.forms.adverb && (
                        <span className="text-[10px] bg-amber-50/50 text-amber-700 border border-amber-100/50 px-2 py-0.5 rounded font-mono">
                          adv: <span className="font-bold">{fam.forms.adverb.word}</span>
                        </span>
                      )}
                    </div>

                    {/* Arrow Indicator on hover */}
                    <div className="absolute right-3.5 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity text-blue-600">
                      <ArrowRight className="w-5 h-5 translate-x-1 group-hover:translate-x-0 transition-transform" />
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-400">
                  <SlidersHorizontal className="w-10 h-10 mb-2 text-slate-300" />
                  <p className="text-sm font-semibold text-slate-700">{t('noResults', currentLanguage)}</p>
                  <p className="text-xs max-w-xs mt-1">{t('trySearchWords', currentLanguage)}</p>
                </div>
              )}
            </div>
          </motion.div>
        ) : (
          /* Detail Mode */
          <motion.div
            key="details"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 flex flex-col overflow-hidden"
          >
            {/* Top Back Nav Bar */}
            <div className="p-3 bg-white border-b border-slate-200 flex items-center justify-between select-none shadow-sm shrink-0">
              <button
                onClick={() => setSelectedFamilyId(null)}
                className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs rounded-xl flex items-center gap-1 cursor-pointer hover:text-slate-800 transition-colors text-slate-600 font-bold"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{t('back', currentLanguage)}</span>
              </button>
              <span className="text-xs uppercase font-extrabold tracking-widest text-blue-600 text-center">
                {t('lexicalTree', currentLanguage)}
              </span>
              <div className="w-12"></div> {/* alignment balancer */}
            </div>

            {/* Scrollable Details Panel */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-5 pb-8 bg-slate-50/50">
              {activeFamily && (
                <>
                  {/* Word Family Tree */}
                  <WordFamilyTree family={activeFamily} currentLanguage={currentLanguage} />

                  {/* Synonyms & Antonyms block */}
                  <div className="bg-white rounded-2xl border border-slate-200 p-4.5 shadow-sm flex flex-col gap-4">
                    <div>
                      <h4 className="text-xs text-slate-900 uppercase tracking-wider font-bold mb-1 flex items-center gap-1.5">
                        <Smile className="w-4 h-4 text-blue-650" />
                        {t('semanticAssociation', currentLanguage)}
                      </h4>
                      <p className="text-[11px] text-slate-500">{t('synonymsAntonyms', currentLanguage)}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3.5">
                      {/* Synonyms */}
                      <div className="bg-emerald-50/30 rounded-xl p-3 border border-emerald-100 flex flex-col gap-1.5">
                        <span className="text-[10px] text-emerald-700 font-extrabold uppercase tracking-wide">
                          {t('synonyms', currentLanguage)}
                        </span>
                        <div className="flex flex-wrap gap-1">
                          {activeFamily.synonyms.map((syn) => (
                            <span 
                              key={syn} 
                              className="text-[11px] px-2 py-0.5 rounded bg-white border border-emerald-250/40 text-emerald-700 font-sans font-medium"
                            >
                              {syn}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Antonyms */}
                      <div className="bg-rose-50/30 rounded-xl p-3 border border-rose-100 flex flex-col gap-1.5">
                        <span className="text-[10px] text-rose-700 font-extrabold uppercase tracking-wide">
                          {t('antonyms', currentLanguage)}
                        </span>
                        <div className="flex flex-wrap gap-1">
                          {activeFamily.antonyms.map((ant) => (
                            <span 
                              key={ant} 
                              className="text-[11px] px-2 py-0.5 rounded bg-white border border-rose-250/40 text-rose-700 font-sans font-medium"
                            >
                              {ant}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
