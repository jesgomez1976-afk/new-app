/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GrammarRuleSection } from '../types';

export const grammarRules: GrammarRuleSection[] = [
  {
    id: 'verb-to-noun',
    title: '1. De Verbo a Sustantivo',
    subtitle: 'Acción o resultado de un proceso',
    generalRule: 'Muchos verbos en inglés forman sustantivos añadiendo sufijos específicos o, en ocasiones, modificando la raíz de la palabra de forma irregular.',
    patterns: [
      {
        suffix: '-tion',
        rule: 'Acción formal / oficial',
        example: 'verb + -tion',
        process: 'inform ➔ information'
      },
      {
        suffix: '-sion',
        rule: 'Expresa acción o estado mental',
        example: 'verb + -sion',
        process: 'decide ➔ decision'
      },
      {
        suffix: '-ment',
        rule: 'Denota el resultado de una acción',
        example: 'verb + -ment',
        process: 'develop ➔ development'
      },
      {
        suffix: '-al',
        rule: 'Proceso formal de una acción',
        example: 'verb + -al',
        process: 'arrive ➔ arrival'
      },
      {
        suffix: '-ance / -ence',
        rule: 'Estado, cualidad o acción continua',
        example: 'verb + -ance / -ence',
        process: 'perform ➔ performance'
      },
      {
        suffix: '-ing',
        rule: 'Actividad que se experimenta',
        example: 'verb + -ing',
        process: 'read ➔ reading'
      },
      {
        suffix: 'irregular',
        rule: 'Cambio total de raíz',
        example: 'cambio total',
        process: 'succeed ➔ success'
      }
    ],
    keySecret: 'Regla Clave sobre terminación (-ceed / -cede):',
    keySecretDetail: [
      'Si el verbo original termina en "-ceed" o "-cede", el sustantivo resultante suele ser IRREGULAR en "-cess" o "-cessation":',
      '• succeed ➔ success (éxito)',
      '• proceed ➔ process (proceso)',
      '• exceed ➔ excess (exceso)'
    ]
  },
  {
    id: 'noun-to-adj',
    title: '2. De Sustantivo a Adjetivo',
    subtitle: 'Atribución de cualidades o estados',
    generalRule: 'Para describir que algo o alguien posee las características de un sustantivo, formamos adjetivos utilizando los sufijos -ful, -less, -al, -ic, -ive, -y, -ous.',
    patterns: [
      {
        suffix: '-ful',
        rule: 'Lleno de o que tiene la cualidad (positivo)',
        example: 'noun + -ful',
        process: 'success ➔ successful / beauty ➔ beautiful'
      },
      {
        suffix: '-less',
        rule: 'Sin o carente de dicha cualidad (negativo)',
        example: 'noun + -less',
        process: 'care ➔ careless / hope ➔ hopeless'
      },
      {
        suffix: '-ous',
        rule: 'Caracterizado por tener la cualidad',
        example: 'noun + -ous',
        process: 'danger ➔ dangerous'
      },
      {
        suffix: '-etic / -ic',
        rule: 'Relacionado con la naturaleza de',
        example: 'noun + -etic',
        process: 'energy ➔ energetic / athlete ➔ athletic'
      },
      {
        suffix: '-ive',
        rule: 'Tendencia a realizar o causar algo',
        example: 'noun + -ive',
        process: 'creation ➔ creative / attract ➔ attractive'
      },
      {
        suffix: '-y',
        rule: 'Cubierto de, lleno de o propenso a',
        example: 'noun + -y',
        process: 'dirt ➔ dirty / rain ➔ rainy'
      }
    ],
    keySecret: 'Regla Clave de transformación:',
    keySecretDetail: [
      'Si un sustantivo termina originalmente en "-ness", "-ity" o "-tion", el adjetivo suele terminar consistentemente en "-ous" o "-ive":',
      '• Es decir, el sufijo del adjetivo suele acoplarse cancelando las últimas letras de sustantivos extensivos: creation ➔ creative.'
    ]
  },
  {
    id: 'adj-to-adv',
    title: '3. De Adjetivo a Adverbio',
    subtitle: 'Modo o manera de ejecutar acciones',
    generalRule: 'Formamos adverbios para indicar la manera en que ocurre algo. La regla maestra en inglés es añadir el sufijo -ly directamente al adjetivo.',
    patterns: [
      {
        suffix: '-ly',
        rule: 'Añadir -ly al final',
        example: 'adj + -ly',
        process: 'successful ➔ successfully'
      },
      {
        suffix: '-ly (y ➔ i)',
        rule: 'Si termina en "y", cambia por "i" y añade "-ly"',
        example: 'happy ➔ happily',
        process: 'easy ➔ easily / dirty ➔ dirtily'
      }
    ],
    keySecret: 'Excepción de los Adjetivos terminados en "-ic":',
    keySecretDetail: [
      'Si el adjetivo de origen termina en "-ic", en lugar de añadir "-ly" simplemente, se debe añadir "-ically" alternando la pronunciación:',
      '• basic ➔ basically',
      '• energetic ➔ energetically',
      '• dramatic ➔ dramatically'
    ]
  }
];

export const goldRules = {
  title: 'El Método de Oro en 3 Pasos',
  steps: [
    {
      num: '1',
      action: 'Identifica la Raíz (Root / Lexema)',
      desc: 'Encuentra sobre qué núcleo semántico gira la palabra. Ej: la raíz de successful es success.'
    },
    {
      num: '2',
      action: 'Aplica el sufijo por categoría',
      desc: '• Verbo ➔ Sustantivo: -tion, -sion, -ment, -al, -ance, -ing\n• Sustantivo ➔ Adjetivo: -ful, -less, -ous, -ive, -al, -ic, -y\n• Adjetivo ➔ Adverbio: -ly, -ically'
    },
    {
      num: '3',
      action: 'Estudia las irregularidades clave',
      desc: 'Irregularidades comunes como terminaciones en -ceed/-cede (succeed ➔ success) o pérdidas vocálicas (beauty ➔ beautiful) facilitan memorizar todo el espectro.'
    }
  ]
};
