/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WordFamily } from '../types';

export const wordFamilies: WordFamily[] = [
  {
    id: 'succeed',
    lexeme: 'succed-',
    lexemeDefinition: 'Raíz latina que significa "seguir, avanzar o alcanzar un resultado deseado".',
    lexemeTranslation: 'Tener éxito / Lograr',
    category: 'Éxito y Logro',
    synonyms: ['achieve', 'win', 'accomplish', 'prevail'],
    antonyms: ['fail', 'lose', 'miscarry', 'flounder'],
    forms: {
      verb: {
        word: 'succeed',
        suffix: 'none',
        translation: 'Tener éxito',
        definition: 'Lograr el resultado deseado o planeado.',
        example: 'If you work hard, you will succeed in your carrier.',
        exampleTranslation: 'Si trabajas duro, tendrás éxito en tu carrera.'
      },
      noun: {
        word: 'success',
        suffix: 'irregular',
        translation: 'Éxito',
        definition: 'El logro de un propósito o meta.',
        example: 'Her presentation was a great success.',
        exampleTranslation: 'Su presentación fue un gran éxito.'
      },
      adjective: {
        word: 'successful',
        suffix: '-ful',
        translation: 'Exitoso / próspero',
        definition: 'Que tiene éxito o logra buenos resultados.',
        example: 'They run a very successful family business.',
        exampleTranslation: 'Ellos dirigen un negocio familiar muy exitoso.'
      },
      adverb: {
        word: 'successfully',
        suffix: '-ly',
        translation: 'Exitosamente',
        definition: 'De una manera que logra el resultado deseado.',
        example: 'The surgery was successfully completed.',
        exampleTranslation: 'La cirugía fue completada exitosamente.'
      }
    }
  },
  {
    id: 'create',
    lexeme: 'creat-',
    lexemeDefinition: 'Del latín "creatus", que significa "traer a la existencia, producir o causar".',
    lexemeTranslation: 'Crear / Producir',
    category: 'Creación e Intelecto',
    synonyms: ['make', 'produce', 'generate', 'design'],
    antonyms: ['destroy', 'demolish', 'ruin', 'annihilate'],
    forms: {
      verb: {
        word: 'create',
        suffix: 'none',
        translation: 'Crear',
        definition: 'Traer algo a la existencia por primera vez.',
        example: 'We want to create a new mobile application.',
        exampleTranslation: 'Queremos crear una nueva aplicación móvil.'
      },
      noun: {
        word: 'creation',
        suffix: '-tion',
        translation: 'Creación',
        definition: 'El acto o proceso de traer algo a la existencia.',
        example: 'The creation of the internet changed the world.',
        exampleTranslation: 'La creación del internet cambió el mundo.'
      },
      adjective: {
        word: 'creative',
        suffix: '-ive',
        translation: 'Creativo',
        definition: 'Que tiene o demuestra imaginación u originalidad.',
        example: 'Children are highly creative when playing.',
        exampleTranslation: 'Los niños son muy creativos cuando juegan.'
      },
      adverb: {
        word: 'creatively',
        suffix: '-ly',
        translation: 'Creativamente',
        definition: 'De manera original, artística o imaginativa.',
        example: 'She solved the complex problem creatively.',
        exampleTranslation: 'Ella resolvió el problema complejo creativamente.'
      }
    }
  },
  {
    id: 'decide',
    lexeme: 'decid-',
    lexemeDefinition: 'Del latín "decidere", que significa literalmente "cortar de raíz, determinar o resolver".',
    lexemeTranslation: 'Decidir / Resolver',
    category: 'Creación e Intelecto',
    synonyms: ['choose', 'resolve', 'determine', 'settle'],
    antonyms: ['hesitate', 'waver', 'doubt', 'vacillate'],
    forms: {
      verb: {
        word: 'decide',
        suffix: 'none',
        translation: 'Decidir',
        definition: 'Tomar una opción tras reflexionar sobre varias posibilidades.',
        example: 'You must decide which path to follow.',
        exampleTranslation: 'Debes decidir qué camino seguir.'
      },
      noun: {
        word: 'decision',
        suffix: '-sion',
        translation: 'Decisión',
        definition: 'Conclusión o resolución alcanzada tras considerar opciones.',
        example: 'It was a very difficult decision for the team.',
        exampleTranslation: 'Fue una decisión muy difícil para el equipo.'
      },
      adjective: {
        word: 'decisive',
        suffix: '-ive',
        translation: 'Decisivo / determinado',
        definition: 'Que resuelve una duda o que actúa con firmeza y rapidez.',
        example: 'We need to take decisive action to save the project.',
        exampleTranslation: 'Necesitamos tomar medidas decisivas para salvar el proyecto.'
      },
      adverb: {
        word: 'decisively',
        suffix: '-ly',
        translation: 'Decisivamente / con firmeza',
        definition: 'Hacer algo con absoluta seguridad y sin vacilar.',
        example: 'He acted decisively during the crisis.',
        exampleTranslation: 'Él actuó decisivamente durante la crisis.'
      }
    }
  },
  {
    id: 'enjoy',
    lexeme: 'joy-',
    lexemeDefinition: 'De la raíz que expresa "regocijo, gozo, deleite y placer activo".',
    lexemeTranslation: 'Gozar / Disfrutar',
    category: 'Estado y Emoción',
    synonyms: ['like', 'appreciate', 'relish', 'love'],
    antonyms: ['hate', 'dislike', 'detest', 'loathe'],
    forms: {
      verb: {
        word: 'enjoy',
        prefix: 'en-',
        suffix: 'none',
        translation: 'Disfrutar',
        definition: 'Sentir satisfacción o placer al realizar una actividad.',
        example: 'I enjoy reading books on rainy weekends.',
        exampleTranslation: 'Disfruto leer libros en fines de semana lluviosos.'
      },
      noun: {
        word: 'enjoyment',
        suffix: '-ment',
        translation: 'Goce / disfrute',
        definition: 'El estado o proceso de experimentar placer.',
        example: 'The children got much enjoyment from the magic show.',
        exampleTranslation: 'Los niños obtuvieron mucho disfrute del show de magia.'
      },
      adjective: {
        word: 'enjoyable',
        suffix: '-able',
        translation: 'Agradable / ameno',
        definition: 'Que da placer, satisfacción o regocijo.',
        example: 'We had a very enjoyable dinner together.',
        exampleTranslation: 'Tuvimos una cena muy agradable juntos.'
      },
      adverb: {
        word: 'enjoyably',
        suffix: '-ly',
        translation: 'Agradablemente',
        definition: 'De manera agradable o divertida.',
        example: 'The afternoon passed enjoyably in the garden.',
        exampleTranslation: 'La tarde transcurrió agradablemente en el jardín.'
      }
    }
  },
  {
    id: 'differ',
    lexeme: 'differ-',
    lexemeDefinition: 'Del latín "differre", que significa "llevar en direcciones opuestas, ser distinto".',
    lexemeTranslation: 'Diferir / Distinguir',
    category: 'Creación e Intelecto',
    synonyms: ['vary', 'diverge', 'disagree', 'clash'],
    antonyms: ['agree', 'match', 'resemble', 'coincide'],
    forms: {
      verb: {
        word: 'differ',
        suffix: 'none',
        translation: 'Diferir / variar',
        definition: 'Ser diferente en características o en opinión respecto a otro.',
        example: 'Our scientific opinions differ on this topic.',
        exampleTranslation: 'Nuestras opiniones científicas difieren en este tema.'
      },
      noun: {
        word: 'difference',
        suffix: '-ence',
        translation: 'Diferencia',
        definition: 'La cualidad o estado que hace que dos cosas no sean iguales.',
        example: 'There is a huge difference between the two methods.',
        exampleTranslation: 'Hay una enorme diferencia entre los dos métodos.'
      },
      adjective: {
        word: 'different',
        suffix: '-ent',
        translation: 'Diferente',
        definition: 'Que no es igual o que posee características distintas.',
        example: 'They come from different cultural backgrounds.',
        exampleTranslation: 'Vienen de orígenes culturales diferentes.'
      },
      adverb: {
        word: 'differently',
        suffix: '-ly',
        translation: 'Diferentemente / de otra forma',
        definition: 'De una manera distinta.',
        example: 'Try to view the situation differently.',
        exampleTranslation: 'Intenta ver la situación de manera diferente.'
      }
    }
  },
  {
    id: 'attract',
    lexeme: 'attract-',
    lexemeDefinition: 'Del latín "attrahere", que significa "tirar hacia, traer cerca o imantar".',
    lexemeTranslation: 'Atraer / Imantar',
    category: 'Acción e Interacción',
    synonyms: ['draw', 'allure', 'appeal', 'charm'],
    antonyms: ['repel', 'disgust', 'repulse', 'scare'],
    forms: {
      verb: {
        word: 'attract',
        suffix: 'none',
        translation: 'Atraer',
        definition: 'Tirar hacia sí o capturar el interés o atención de alguien.',
        example: 'Bright flowers attract hummingbirds naturally.',
        exampleTranslation: 'Las flores brillantes atraen colibríes de forma natural.'
      },
      noun: {
        word: 'attraction',
        suffix: '-tion',
        translation: 'Atracción',
        definition: 'Cualidad de atraer; o algo de gran interés turístico o estético.',
        example: 'The historic museum is the city\'s main attraction.',
        exampleTranslation: 'El museo histórico es la atracción principal de la ciudad.'
      },
      adjective: {
        word: 'attractive',
        suffix: '-ive',
        translation: 'Atractivo',
        definition: 'Que despierta interés, agrado o simpatía estética o emocional.',
        example: 'They offer a very attractive salary package.',
        exampleTranslation: 'Ofrecen un paquete salarial muy atractivo.'
      },
      adverb: {
        word: 'attractively',
        suffix: '-ly',
        translation: 'Atractivamente',
        definition: 'De modo agradable, agradable a la vista, o tentador.',
        example: 'The dishes were attractively organized on the buffet.',
        exampleTranslation: 'Los platos estaban atractivamente organizados en el buffet.'
      }
    }
  },
  {
    id: 'inform',
    lexeme: 'form-',
    lexemeDefinition: 'Del latín "informare", que significa "dar forma a la mente, instruir o reportar".',
    lexemeTranslation: 'Informar / Instruir',
    category: 'Acción e Interacción',
    synonyms: ['notify', 'tell', 'advise', 'report'],
    antonyms: ['mislead', 'deceive', 'hide', 'conceal'],
    forms: {
      verb: {
        word: 'inform',
        prefix: 'in-',
        suffix: 'none',
        translation: 'Informar',
        definition: 'Comunicar hechos o noticias a alguien de forma clara.',
        example: 'Please inform me of any schedule changes.',
        exampleTranslation: 'Por favor infórmame sobre cualquier cambio de horario.'
      },
      noun: {
        word: 'information',
        suffix: '-tion',
        translation: 'Información',
        definition: 'Datos, conocimientos o reportes comunicados sobre un tema.',
        example: 'We found very useful information on their website.',
        exampleTranslation: 'Encontramos información muy útil en su sitio web.'
      },
      adjective: {
        word: 'informative',
        suffix: '-ive',
        translation: 'Informativo',
        definition: 'Que instruye o proporciona mucha información valiosa.',
        example: 'The lecture was extremely informative and clear.',
        exampleTranslation: 'La conferencia fue extremadamente informativa y clara.'
      },
      adverb: {
        word: 'informatively',
        suffix: '-ly',
        translation: 'Informativamente',
        definition: 'De forma tal que proporciona información útil.',
        example: 'The handbook explains each feature informatively.',
        exampleTranslation: 'El manual explica cada característica de forma informativa.'
      }
    }
  },
  {
    id: 'develop',
    lexeme: 'velop-',
    lexemeDefinition: 'Del francés antiguo "desvoloper", que significa "desenvolver, hacer crecer o madurar".',
    lexemeTranslation: 'Desarrollar / Crecer',
    category: 'Creación e Intelecto',
    synonyms: ['grow', 'advance', 'evolve', 'expand'],
    antonyms: ['stagnate', 'regress', 'shrink', 'deteriorate'],
    forms: {
      verb: {
        word: 'develop',
        suffix: 'none',
        translation: 'Desarrollar',
        definition: 'Hacer pasar algo por una serie de estados sucesivos para mejorarlo.',
        example: 'The software team will develop a new update.',
        exampleTranslation: 'El equipo de software desarrollará una nueva actualización.'
      },
      noun: {
        word: 'development',
        suffix: '-ment',
        translation: 'Desarrollo',
        definition: 'El crecimiento o progreso continuo de algo en dirección positiva.',
        example: 'Sustainable development is crucial for our planet.',
        exampleTranslation: 'El desarrollo sostenible es crucial para nuestro planeta.'
      },
      adjective: {
        word: 'developmental',
        suffix: '-al',
        translation: 'Del desarrollo / madurativo',
        definition: 'Relacionado con las etapas de desarrollo o crecimiento físico/mental.',
        example: 'The psychologist studied the developmental stages of children.',
        exampleTranslation: 'El psicólogo estudió las etapas del desarrollo de los niños.'
      },
      adverb: {
        word: 'developmentally',
        suffix: '-ly',
        translation: 'En términos de desarrollo / evolutivamente',
        definition: 'De manera correspondiente a una etapa de madurez o crecimiento.',
        example: 'This toy is developmentally appropriate for toddlers.',
        exampleTranslation: 'Este juguete es evolutivamente apropiado para niños pequeños.'
      }
    }
  },
  {
    id: 'perform',
    lexeme: 'form-',
    lexemeDefinition: 'Del francés antiguo "parfournir", que significa "completar, llevar a cabo una obra de arte o acción".',
    lexemeTranslation: 'Desempeñar / Interpretar',
    category: 'Acción e Interacción',
    synonyms: ['act', 'present', 'execute', 'achieve'],
    antonyms: ['neglect', 'fail', 'ignore', 'cancel'],
    forms: {
      verb: {
        word: 'perform',
        suffix: 'none',
        translation: 'Llevar a cabo / actuar',
        definition: 'Llevar a cabo una acción, o interpretar una obra artística en público.',
        example: 'The musicians will perform on stage tomorrow night.',
        exampleTranslation: 'Los músicos se presentarán en vivo mañana por la noche.'
      },
      noun: {
        word: 'performance',
        suffix: '-ance',
        translation: 'Rendimiento / función',
        definition: 'El nivel de efectividad al actuar; o una presentación teatral.',
        example: 'The processor delivers a high computing performance.',
        exampleTranslation: 'El procesador ofrece un alto rendimiento computacional.'
      },
      adjective: {
        word: 'performative',
        suffix: '-ative',
        translation: 'Performativo / representativo',
        definition: 'Que produce una acción al ser expresado, o relativo a la actuación.',
        example: 'Her artistic approach turned everyday gestures into performative acts.',
        exampleTranslation: 'Su enfoque artístico convirtió gestos cotidianos en actos performativos.'
      },
      adverb: {
        word: 'performatively',
        suffix: '-ly',
        translation: 'De manera representativa o performativa',
        definition: 'De una manera que enfatiza la performance o ejecución.',
        example: 'The ritual was performatively executed by the members.',
        exampleTranslation: 'El ritual fue ejecutado de manera performativa por los miembros.'
      }
    }
  },
  {
    id: 'read',
    lexeme: 'read',
    lexemeDefinition: 'Del inglés antiguo "rædan", que significa "aconsejar, interpretar signos, interpretar escritos".',
    lexemeTranslation: 'Leer / Descifrar',
    category: 'Creación e Intelecto',
    synonyms: ['peruse', 'scan', 'study', 'interpret'],
    antonyms: ['write', 'ignore', 'overlook'],
    forms: {
      verb: {
        word: 'read',
        suffix: 'none',
        translation: 'Leer',
        definition: 'Mirar y comprender los caracteres de un escrito.',
        example: 'I love to read mystery novels in my bedroom.',
        exampleTranslation: 'Me encanta leer novelas de misterio en mi habitación.'
      },
      noun: {
        word: 'reading',
        suffix: '-ing',
        translation: 'Lectura',
        definition: 'La acción de leer o interpretar un texto.',
        example: 'Reading improves memory and vocabulary enormously.',
        exampleTranslation: 'La lectura mejora la memoria y el vocabulario enormemente.'
      },
      adjective: {
        word: 'readable',
        suffix: '-able',
        translation: 'Legible / interesante de leer',
        definition: 'Que se puede leer con facilidad o agrado.',
        example: 'The user interface needs to use readable fonts.',
        exampleTranslation: 'La interfaz de usuario necesita usar fuentes legibles.'
      },
      adverb: {
        word: 'readably',
        suffix: '-ly',
        translation: 'Claramente / legiblemente',
        definition: 'De forma que se lee con facilidad o placer.',
        example: 'His complex essays were readably written.',
        exampleTranslation: 'Sus complejos ensayos fueron escritos de manera legible.'
      }
    }
  },
  {
    id: 'danger',
    lexeme: 'danger',
    lexemeDefinition: 'Originalmente "dominio o poder", evolucionando a "exposición al daño, perjuicio o riesgo".',
    lexemeTranslation: 'Peligro / Riesgo',
    category: 'Estado y Emoción',
    synonyms: ['hazard', 'peril', 'risk', 'jeopardy'],
    antonyms: ['safety', 'security', 'protection', 'peace'],
    forms: {
      verb: {
        word: 'endanger',
        prefix: 'en-',
        suffix: 'none',
        translation: 'Poner en peligro',
        definition: 'Colocar a alguien o algo en una situación riesgosa.',
        example: 'Wildfires endanger the local animal habitats.',
        exampleTranslation: 'Los incendios forestales ponen en peligro los hábitats animales locales.'
      },
      noun: {
        word: 'danger',
        suffix: 'none',
        translation: 'Peligro',
        definition: 'Posibilidad de que ocurra un daño o desgracia.',
        example: 'The red sign warns of extreme danger ahead.',
        exampleTranslation: 'El letrero rojo advierte de un peligro extremo más adelante.'
      },
      adjective: {
        word: 'dangerous',
        suffix: '-ous',
        translation: 'Peligroso',
        definition: 'Que puede causar daño o provocar pérdidas.',
        example: 'Driving on icy roads is highly dangerous.',
        exampleTranslation: 'Conducir en calles congeladas es altamente peligroso.'
      },
      adverb: {
        word: 'dangerously',
        suffix: '-ly',
        translation: 'Peligrosamente',
        definition: 'De una manera que involucra un gran riesgo o daño.',
        example: 'The water levels are rising dangerously fast.',
        exampleTranslation: 'Los niveles del agua están subiendo peligrosamente rápido.'
      }
    }
  },
  {
    id: 'beauty',
    lexeme: 'beauty',
    lexemeDefinition: 'Derivada del latín "bellus", que denota "armonía de proporciones que produce placer visual".',
    lexemeTranslation: 'Belleza / Hermosura',
    category: 'Estado y Emoción',
    synonyms: ['elegance', 'gorgeousness', 'grace', 'loveliness'],
    antonyms: ['ugliness', 'hideousness', 'plainness', 'unattractiveness'],
    forms: {
      verb: {
        word: 'beautify',
        suffix: '-ify',
        translation: 'Embellecer',
        definition: 'Hacer que algo se vea más hermoso o estético.',
        example: 'They planted colorful roses to beautify the main park.',
        exampleTranslation: 'Plantaron rosas coloridas para embellecer el parque principal.'
      },
      noun: {
        word: 'beauty',
        suffix: 'none',
        translation: 'Belleza',
        definition: 'Armonía visual o estética que deleita al observador.',
        example: 'The mountain view showed a stunning natural beauty.',
        exampleTranslation: 'La vista de la montaña mostraba una impresionante belleza natural.'
      },
      adjective: {
        word: 'beautiful',
        suffix: '-ful',
        translation: 'Hermoso / bello',
        definition: 'Que posee belleza y agrada a la vista o el espíritu.',
        example: 'It is a beautiful morning to go for a run.',
        exampleTranslation: 'Es una hermosa mañana para salir a correr.'
      },
      adverb: {
        word: 'beautifully',
        suffix: '-ly',
        translation: 'Hermosamente',
        definition: 'De una manera excelente, estética o armoniosa.',
        example: 'The living room is beautifully decorated.',
        exampleTranslation: 'La sala de estar está hermosamente decorada.'
      }
    }
  },
  {
    id: 'energy',
    lexeme: 'energ-',
    lexemeDefinition: 'Del griego "energeia", que denota "fuerza en acción, vigor y capacidad de trabajo".',
    lexemeTranslation: 'Energía / Vigor',
    category: 'Estado y Emoción',
    synonyms: ['vigor', 'vitality', 'power', 'force'],
    antonyms: ['lethargy', 'weakness', 'fatigue', 'apathy'],
    forms: {
      verb: {
        word: 'energize',
        suffix: '-ize',
        translation: 'Energizar / infundir vigor',
        definition: 'Dar energía, entusiasmo o fuerza activa a algo o alguien.',
        example: 'Upbeat music tends to energize athletes before a game.',
        exampleTranslation: 'La música alegre suele energizar a los atletas antes de un juego.'
      },
      noun: {
        word: 'energy',
        suffix: 'none',
        translation: 'Energía',
        definition: 'Fuerza activa o poder capaz de realizar un trabajo o acción.',
        example: 'Solar energy is a clean alternative source of power.',
        exampleTranslation: 'La energía solar es una fuente de poder limpia y alternativa.'
      },
      adjective: {
        word: 'energetic',
        suffix: '-etic',
        translation: 'Enérgico / activo',
        definition: 'Que tiene mucha fuerza, dinamismo o vitalidad.',
        example: 'She is an energetic dancer who fills the stage with life.',
        exampleTranslation: 'Ella es una bailarina enérgica que llena el escenario de vida.'
      },
      adverb: {
        word: 'energetically',
        suffix: '-ically',
        translation: 'Enérgicamente / vigorosamente',
        definition: 'Realizar una actividad con gran vigor, rapidez o fuerza.',
        example: 'The kids played energetically in the swimming pool.',
        exampleTranslation: 'Los niños jugaron enérgicamente en la piscina.'
      }
    }
  },
  {
    id: 'dirt',
    lexeme: 'dirt',
    lexemeDefinition: 'De origen germánico antiguo ("dritan" - excremento, lodo), transitando a "tierra, impurezas o lodo".',
    lexemeTranslation: 'Tierra / Mugre',
    category: 'Estado y Emoción',
    synonyms: ['mud', 'grime', 'dust', 'filth'],
    antonyms: ['purity', 'cleanliness', 'spotlessness'],
    forms: {
      verb: {
        word: 'dirty',
        suffix: 'none',
        translation: 'Ensuciar',
        definition: 'Manchar con tierra, polvo o cualquier otra impureza.',
        example: 'Do not dirty your shoes before the wedding photo.',
        exampleTranslation: 'No ensucies tus zapatos antes de la foto de la boda.'
      },
      noun: {
        word: 'dirt',
        suffix: 'none',
        translation: 'Mugre / suciedad / tierra',
        definition: 'Sustancia sucia, polvo o lodo depositado sobre superficies.',
        example: 'The soccer ball was covered in thick grey dirt.',
        exampleTranslation: 'El balón de fútbol estaba cubierto de gruesa tierra gris.'
      },
      adjective: {
        word: 'dirty',
        suffix: '-y',
        translation: 'Sucio',
        definition: 'Que tiene mugre, polvo o no está limpio.',
        example: 'Please put your dirty laundry in the basket.',
        exampleTranslation: 'Por favor pon tu ropa sucia en la canasta.'
      },
      adverb: {
        word: 'dirtily',
        suffix: '-ly',
        translation: 'Suciamente',
        definition: 'De manera sucia, deshonestamente, o descuidada.',
        example: 'The dirty oil dripped dirtily onto the clean concrete.',
        exampleTranslation: 'El aceite sucio goteó suciamente sobre el concreto limpio.'
      }
    }
  },
  {
    id: 'arrive',
    lexeme: 'riv-',
    lexemeDefinition: 'Del latín "adripare", que significa "tocar la orilla de un río (ripa), desembarcar o arribar".',
    lexemeTranslation: 'Llegar / Arribar',
    category: 'Acción e Interacción',
    synonyms: ['reach', 'appear', 'land', 'show up'],
    antonyms: ['leave', 'depart', 'go', 'exit'],
    forms: {
      verb: {
        word: 'arrive',
        suffix: 'none',
        translation: 'Llegar',
        definition: 'Alcanzar el final de un viaje o destino.',
        example: 'We expect the trains to arrive on schedule.',
        exampleTranslation: 'Esperamos que los trenes lleguen a tiempo.'
      },
      noun: {
        word: 'arrival',
        suffix: '-al',
        translation: 'Llegada',
        definition: 'El hecho de alcanzar el destino o arribar a un lugar.',
        example: 'Hundreds of fans awaited the arrival of the pop star.',
        exampleTranslation: 'Cientos de fans esperaban la llegada de la estrella del pop.'
      },
      adjective: {
        word: 'arriving',
        suffix: '-ing',
        translation: 'Entrante / que llega',
        definition: 'Que está en proceso de llegar o aproximarse.',
        example: 'The airport screen lists all arriving flights in green.',
        exampleTranslation: 'La pantalla del aeropuerto lista todos los vuelos entrantes en verde.'
      },
      adverb: null // No standard adverb for "arrive" family. Showing how some families have blanks!
    }
  }
];
