/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ComparativeWord {
  word: string;
  meaning: string; // Meaning (Band 9 nuance)
  meaningTranslations: { [langCode: string]: string }; // Translations to other target languages
  bestContexts: string;
  bestContextsTranslations: { [langCode: string]: string };
  example: string;
}

export interface ComparativeGroup {
  id: string;
  title: string; // e.g. "harsh • tough • hard • brutal"
  type: 'verb' | 'adjective' | 'noun';
  category: string; // e.g. "Adverbs & Adjectives of Intensity", "Verbs of Creation"
  categoryTranslations: { [langCode: string]: string };
  subcategory: string; // e.g. "Difficulty & Severity", "Cognitive Production"
  subcategoryTranslations: { [langCode: string]: string };
  description: string; // A short text explaining the global contrast
  descriptionTranslations: { [langCode: string]: string };
  words: ComparativeWord[];
}

export const comparativeTables: ComparativeGroup[] = [
  {
    id: 'difficulty',
    title: 'harsh • tough • hard • brutal',
    type: 'adjective',
    category: 'Adjectives of Intensity',
    categoryTranslations: {
      es: 'Adjetivos de Intensidad',
      pt: 'Adjetivos de Intensidade',
      fr: 'Adjectifs d\'Intensité',
      it: 'Aggettivi di Intensità',
      de: 'Adjektive der Intensität'
    },
    subcategory: 'Difficulty & Severity',
    subcategoryTranslations: {
      es: 'Dificultad y Severidad',
      pt: 'Dificuldade e Severidade',
      fr: 'Difficulté & Sévérité',
      it: 'Difficoltà e Severità',
      de: 'Schwierigkeit und Härte'
    },
    description: 'These adjectives describe various degrees of physical, environmental, or emotional toughness, with critical differences in sub-contexts.',
    descriptionTranslations: {
      es: 'Estos adjetivos describen varios grados de dureza física, ambiental o emocional, con diferencias críticas en los subcontextos de uso.',
      pt: 'Estes adjetivos descrevem vários graus de dureza física, ambiental ou emocional, com diferenças críticas nos subcontextos de uso.',
      fr: 'Ces adjectifs décrivent différents degrés de dureté physique, environnementale ou émotionnelle, avec des différences cruciales selon le contexte.',
      it: 'Questi aggettivi descrivono vari gradi di durezza fisica, ambientale o emotiva, con differenze critiche nei contesti d\'uso.',
      de: 'Diese Adjektive beschreiben verschiedene Grade der physikalischen, umweltbedingten oder emotionalen Härte, mit kritischen Unterschieden.'
    },
    words: [
      {
        word: 'Harsh',
        meaning: 'Strong, severe, uncomfortable; often linked to environment, criticism, or conditions.',
        meaningTranslations: {
          es: 'Fuerte, severo, incómodo; a menudo relacionado con el medio ambiente, críticas o condiciones.',
          pt: 'Forte, severo, desconfortável; frequentemente ligado ao ambiente, críticas ou condições.',
          fr: 'Fort, sévère, inconfortable ; souvent lié à l\'environnement, à la critique ou aux conditions.',
          it: 'Forte, severo, scomodo; spesso legato all\'ambiente, a critiche o condizioni.',
          de: 'Stark, streng, unangenehm; oft verbunden mit Umwelt, Kritik oder Bedingungen.'
        },
        bestContexts: 'Weather, climate, rules, criticism, realities of life.',
        bestContextsTranslations: {
          es: 'Clima, tiempo, normas, críticas, realidades de la vida.',
          pt: 'Clima, tempo, regras, críticas, realidades da vida.',
          fr: 'Météo, climat, règles, critiques, réalités de la vie.',
          it: 'Meteo, clima, regole, critiche, realtà della vita.',
          de: 'Wetter, Klima, Regeln, Kritik, Realitäten des Lebens.'
        },
        example: 'The winter was so harsh that it completely reshaped my daily routine and mindset.'
      },
      {
        word: 'Tough',
        meaning: 'Difficult but manageable; requires resilience, effort, and inner strength.',
        meaningTranslations: {
          es: 'Difícil pero manejable; requiere resiliencia, esfuerzo y fuerza de voluntad.',
          pt: 'Difícil mas controlável; exige resiliência, esforço e força de vontade.',
          fr: 'Difficile mais gérable ; exige de la résilience, de l\'effort et de la force intérieure.',
          it: 'Difficile ma gestibile; richiede resilienza, sforzo e forza interiore.',
          de: 'Schwer, aber bewältigbar; erfordert Belastbarkeit, Anstrengung und Willenskraft.'
        },
        bestContexts: 'Life challenges, decisions, jobs, personal growth.',
        bestContextsTranslations: {
          es: 'Desafíos de la vida, decisiones, empleos, crecimiento personal.',
          pt: 'Desafios da vida, decisões, empregos, crescimento pessoal.',
          fr: 'Défis de la vie, décisions, emplois, croissance personnelle.',
          it: 'Sfide della vita, decisioni, lavori, crescita personale.',
          de: 'Lebensherausforderungen, Entscheidungen, Jobs, persönliches Wachstum.'
        },
        example: 'It was a tough period, but it taught me discipline and emotional maturity.'
      },
      {
        word: 'Hard',
        meaning: 'Simply difficult; general physical or cognitive difficulty without emotional intensity.',
        meaningTranslations: {
          es: 'Simplemente difícil o duro; dificultad física o cognitiva general sin intensidad emocional.',
          pt: 'Simplesmente difícil; dificuldade física ou cognitiva geral sem intensidade emocional.',
          fr: 'Simplement difficile ; difficulté physique ou cognitive générale sans intensité émotionnelle.',
          it: 'Semplicemente difficile; difficoltà fisica o cognitiva generale senza intensità emotiva.',
          de: 'Einfach schwer oder hart; allgemeine physische oder kognitive Schwierigkeit ohne emotionale Intensität.'
        },
        bestContexts: 'Tasks, exams, skills, learning processes, materials.',
        bestContextsTranslations: {
          es: 'Tareas, exámenes, habilidades, procesos de aprendizaje, materiales.',
          pt: 'Tarefas, exames, habilidades, processos de aprendizado, materiais.',
          fr: 'Tâches, examens, compétences, processus d\'apprentissage, matériaux.',
          it: 'Compiti, esami, abilità, processi di apprendimento, materiali.',
          de: 'Aufgaben, Prüfungen, Fähigkeiten, Lernprozesse, Materialien.'
        },
        example: 'Learning English pronunciation was hard at first, but consistency made a huge difference.'
      },
      {
        word: 'Brutal',
        meaning: 'Extremely severe, relentless, intense, almost overwhelming.',
        meaningTranslations: {
          es: 'Extremadamente severo, implacable, intenso, casi abrumador.',
          pt: 'Extremamente severo, implacável, intenso, quase avassalador.',
          fr: 'Extrêmement sévère, implacable, intense, presque écrasant.',
          it: 'Estremamente severo, implacabile, intenso, quasi schiacciante.',
          de: 'Extrem hart, unerbittlich, intensiv, fast überwältigend.'
        },
        bestContexts: 'Weather extremes, training, schedules, emotional experiences.',
        bestContextsTranslations: {
          es: 'Climas extremos, entrenamiento, horarios, experiencias emocionales.',
          pt: 'Climas extremos, treinamento, horários, experiências emocionais.',
          fr: 'Climat extrême, entraînement, horaires, expériences émotionnelles.',
          it: 'Climi estremi, allenamento, orari, esperienze emotive.',
          de: 'Extreme Wetterbedingungen, Training, Zeitpläne, emotionale Erfahrungen.'
        },
        example: 'The schedule was brutal, yet it pushed me to discover strengths I didn\'t know I had.'
      }
    ]
  },
  {
    id: 'creation_verbs',
    title: 'create • generate • devise • fabricate',
    type: 'verb',
    category: 'Verbs of Action',
    categoryTranslations: {
      es: 'Verbos de Acción',
      pt: 'Verbos de Ação',
      fr: 'Verbes d\'Action',
      it: 'Verbi di Azione',
      de: 'Verben der Handlung'
    },
    subcategory: 'Creation & Inventiveness',
    subcategoryTranslations: {
      es: 'Creación e Inventiva',
      pt: 'Criação e Inventividade',
      fr: 'Création & Inventivité',
      it: 'Creazione e Inventiva',
      de: 'Erschaffung und Erfindungsreichtum'
    },
    description: 'Verbs used to bring things into existence. Nuance spans from general creation of software or art to plotting with cunning ideas.',
    descriptionTranslations: {
      es: 'Verbos usados para traer cosas a la existencia. Los matices varían desde la creación general de software o arte hasta el diseño astuto de ideas.',
      pt: 'Verbos usados para trazer coisas à existência. As nuances variam desde a criação geral de software ou arte até o design astuto de ideias.',
      fr: 'Verbes utilisés pour amener des choses à l\'existence. Les nuances vont de la création générale de logiciels ou d\'art à la conception astucieuse d\'idées.',
      it: 'Verbi usati per dare vita alle cose. Le sfumature variano dalla creazione generale di software o arte al design astuto di idee.',
      de: 'Verben, die verwendet werden, um Dinge ins Leben zu rufen. Die Nuancen reichen von der allgemeinen Erstellung von Software oder Kunst bis zum Entwerfen listiger Ideen.'
    },
    words: [
      {
        word: 'Create',
        meaning: 'To bring something entirely new into existence, focusing heavily on originality or artistic value.',
        meaningTranslations: {
          es: 'Traer algo completamente nuevo a la existencia, centrándose fuertemente en la originalidad o valor artístico.',
          pt: 'Trazer algo completamente novo à existência, com forte foco na originalidade ou no valor artístico.',
          fr: 'Amener quelque chose de complètement nouveau à l\'existence, en se concentrant fortement sur l\'originalité ou la valeur artistique.',
          it: 'Dare vita a qualcosa di completamente nuovo, concentrandosi fortemente sull\'originalità o sul valore artistico.',
          de: 'Etwas völlig Neues ins Leben rufen, wobei der Fokus stark auf Originalität oder künstlerischem Wert liegt.'
        },
        bestContexts: 'Art, design, systems, software, general foundations.',
        bestContextsTranslations: {
          es: 'Arte, diseño, sistemas, software, cimientos generales.',
          pt: 'Arte, design, sistemas, software, fundamentos gerais.',
          fr: 'Art, design, systèmes, logiciels, fondements généraux.',
          it: 'Arte, design, sistemi, software, fondamenta generali.',
          de: 'Kunst, Design, Systeme, Software, allgemeine Grundlagen.'
        },
        example: 'Artists aim to create masterpieces that evoke deep physical and cognitive responses.'
      },
      {
        word: 'Generate',
        meaning: 'To produce or yield results through an automated, physiological, physical, or logical process.',
        meaningTranslations: {
          es: 'Producir o generar resultados a través de un proceso automático, fisiológico, físico o lógico.',
          pt: 'Produzir ou gerar resultados através de um processo automático, fisiológico, físico ou lógico.',
          fr: 'Produire ou générer des résultats par un processus automatisé, physiologique, physique ou logique.',
          it: 'Produrre o generare risultati attraverso un processo automatico, fisiologico, fisico o logico.',
          de: 'Ergebnisse durch einen automatisierten, physiologischen, physikalischen oder logischen Prozess produzieren.'
        },
        bestContexts: 'Electricity, revenue/money, data reports, heat, ideas.',
        bestContextsTranslations: {
          es: 'Electricidad, ingresos/dinero, informes de datos, calor, ideas.',
          pt: 'Eletricidade, receita/dinheiro, relatórios de dados, calor, ideias.',
          fr: 'Électricité, revenus/argent, rapports de données, chaleur, idées.',
          it: 'Elettricità, entrate/denaro, rapporti dati, calore, idee.',
          de: 'Elektrizität, Einnahmen/Geld, Datenberichte, Hitze, Ideen.'
        },
        example: 'The new dynamic marketing strategies managed to generate a 40% increase in revenue.'
      },
      {
        word: 'Devise',
        meaning: 'To invent or plan a complex scheme or system carefully using immense cognitive intellect or clever thinking.',
        meaningTranslations: {
          es: 'Inventar o planificar un plan o sistema complejo con cuidado utilizando un gran intelecto o pensamiento astuto.',
          pt: 'Inventar ou planejar cuidadosamente um plano ou sistema complexo usando grande intelecto ou pensamento astuto.',
          fr: 'Inveneter ou planifier soigneusement un plan ou système complexe en utilisant une grande intelligence ou une pensée astucieuse.',
          it: 'Inventare o pianificare attentamente un piano o sistema complesso utilizzando un grande intelletto o un pensiero astuto.',
          de: 'Ein komplexes System oder einen Plan sorgfältig mit großem Intellekt oder klugem Denken erfinden oder planen.'
        },
        bestContexts: 'Strategies, escape plans, scientific methods, complex algorithms.',
        bestContextsTranslations: {
          es: 'Estrategias, planes de escape, métodos científicos, algoritmos complejos.',
          pt: 'Estratégias, planos de fuga, métodos científicos, algoritmos complexos.',
          fr: 'Stratégies, plans d\'évasion, méthodes scientifiques, algorithmes complexes.',
          it: 'Strategie, piani di fuga, metodi scientifici, algoritmi complessi.',
          de: 'Strategien, Fluchtpläne, wissenschaftliche Methoden, komplexe Algorithmen.'
        },
        example: 'Our cybersecurity team had to devise a foolproof dynamic defense protocol to repel the attack.'
      },
      {
        word: 'Fabricate',
        meaning: 'To build something physically from raw parts, OR to invent a false story/excuse in a manipulative manner.',
        meaningTranslations: {
          es: 'Construir algo físicamente a partir de piezas en bruto, O inventar una historia/excusa falsa con fines manipulativos.',
          pt: 'Construir algo fisicamente a partir de peças brutas, OU inventar uma mentira/desculpa para fins manipulativos.',
          fr: 'Construire physiquement quelque chose à partir de pièces brutes, OU inventer une fausse histoire ou excuse de manière manipulatrice.',
          it: 'Costruire fisicamente qualcosa da parti grezze, OPPURE inventare una storia/scusa falsa a scopo manipolativo.',
          de: 'Etwas physisch aus Rohteilen bauen ODER eine falsche Geschichte/Ausrede zu manipulativen Zwecken erfinden.'
        },
        bestContexts: 'Industrial manufacturing, metals/construction, alibis, official documents, excuses.',
        bestContextsTranslations: {
          es: 'Fabricación industrial, metales/construcción, coartadas, documentos oficiales, excusas.',
          pt: 'Manufatura industrial, metais/construção, álibis, documentos oficiais, desculpas.',
          fr: 'Fabrication industrielle, métaux/construction, alibis, documents officiels, excuses.',
          it: 'Produzione industriale, metalli/costruzioni, alibi, documenti ufficiali, scuse.',
          de: 'Industrielle Fertigung, Metalle/Bauwesen, Alibis, offizielle Dokumente, Ausreden.'
        },
        example: 'They suspects attempted to fabricate an elaborate alibi to hide their coordinates.'
      }
    ]
  },
  {
    id: 'achievement_verbs',
    title: 'achieve • attain • accomplish • fulfill',
    type: 'verb',
    category: 'Verbs of Action',
    categoryTranslations: {
      es: 'Verbos de Acción',
      pt: 'Verbos de Ação',
      fr: 'Verbes d\'Action',
      it: 'Verbi di Azione',
      de: 'Verben der Handlung'
    },
    subcategory: 'Success & Milestone Fulfillment',
    subcategoryTranslations: {
      es: 'Éxito y Cumplimiento de Metas',
      pt: 'Sucesso e Realização de Metas',
      fr: 'Succès et Accomplissement de Jalons',
      it: 'Successo e Raggiungimento di Traguardi',
      de: 'Erfolg und Erreichung von Meilensteinen'
    },
    description: 'Verbs concerning completing goals or reaching milestones. The focus ranges from emotional fulfillment to physical indicators like ranks or scores.',
    descriptionTranslations: {
      es: 'Verbos relacionados con completar metas o alcanzar hitos. El enfoque oscila entre el sentido de plenitud emocional y los indicadores físicos como rangos o puntuaciones.',
      pt: 'Verbos relacionados com completar metas ou atingir marcos. O foco varia de preenchimento emocional a indicadores físicos como classificações ou pontuações.',
      fr: 'Verbes concernant l\'accomplissement d\'objectifs ou de jalons. L\'accent va de l\'épanouissement émotionnel aux indicateurs physiques comme les rangs ou les scores.',
      it: 'Verbi relativi al completamento di obiettivi o al raggiungimento di traguardi. L\'attenzione spazia dalla pienezza emotiva a indicatori fisici come gradi o punteggi.',
      de: 'Verben im Zusammenhang mit dem Erreichen von Zielen oder Meilensteinen. Der Fokus reicht von emotionaler Erfüllung bis hin zu physischen Indikatoren wie Rängen oder Scores.'
    },
    words: [
      {
        word: 'Achieve',
        meaning: 'To successfully carry out or reach a major goal after long-term dedicated effort, skill, or courage.',
        meaningTranslations: {
          es: 'Llevar a cabo con éxito o alcanzar una meta principal después de un esfuerzo dedicado a largo plazo, habilidad o valentía.',
          pt: 'Realizar com sucesso ou alcançar um objetivo importante após longo esforço dedicado, habilidade ou coragem.',
          fr: 'Mener à bien ou atteindre un objectif majeur après des efforts dévoués à long terme, de l\'habileté ou du courage.',
          it: 'Portare a termine con successo o raggiungere un obiettivo importante dopo sforzi dedicati a lungo termine, abilità o coraggio.',
          de: 'Ein wichtiges Ziel nach langfristigem, engagiertem Einsatz, Geschick oder Mut erfolgreich umsetzen oder erreichen.'
        },
        bestContexts: 'Long-term dreams, business goals, status, academic degrees, high success indicators.',
        bestContextsTranslations: {
          es: 'Sueños a largo plazo, objetivos comerciales, estatus, títulos académicos, altos indicadores de éxito.',
          pt: 'Sonhos a longo prazo, objetivos comerciais, status, diplomas acadêmicos, altos indicadores de sucesso.',
          fr: 'Rêves à long terme, objectifs commerciaux, statut, diplômes universitaires, indicateurs de réussite élevés.',
          it: 'Sogni a lungo termine, obiettivi aziendali, status, lauree accademiche, alti indicatori di successo.',
          de: 'Langfristige Träume, Geschäftsziele, Status, akademische Grade, hohe Erfolgsindikatoren.'
        },
        example: 'It takes perseverance to achieve a professional-level proficiency in a foreign language.'
      },
      {
        word: 'Attain',
        meaning: 'To arrive at or reach a specific measurable point, scale, standard, physical height, or official age.',
        meaningTranslations: {
          es: 'Llegar a o alcanzar un punto mensurable específico, escala, estándar, altura física o edad oficial.',
          pt: 'Chegar a ou atingir um ponto mensurável específico, escala, padrão, altura física ou idade oficial.',
          fr: 'Arriver à ou atteindre un point mesurable spécifique, une échelle, une norme, une hauteur physique ou un âge officiel.',
          it: 'Arrivare o raggiungere uno specifico punto misurabile, scala, standard, altezza fisica o età ufficiale.',
          de: 'Einen bestimmten messbaren Punkt, eine Skala, einen Standard, eine physische Höhe oder ein offizielles Alter erreichen.'
        },
        bestContexts: 'Measurable state, heights, specific ages, numerical speed, standard criteria.',
        bestContextsTranslations: {
          es: 'Estado mensurable, alturas, edades específicas, velocidad numérica, criterios estándares.',
          pt: 'Estado mensurável, alturas, idades específicas, velocidade numérica, critérios padrão.',
          fr: 'État mesurable, hauteurs, âges spécifiques, vitesse numérique, critères standards.',
          it: 'Stato misurabile, altezze, età specifiche, velocità numerica, criteri standard.',
          de: 'Messbarer Zustand, Höhen, bestimmte Alter, numerische Geschwindigkeit, Standardkriterien.'
        },
        example: 'With rigorous scientific training, the compound will attain maximum chemical stability.'
      },
      {
        word: 'Accomplish',
        meaning: 'To finish or complete a specific task, assignment, or set of obligations successfully.',
        meaningTranslations: {
          es: 'Terminar o completar una tarea específica, asignación o conjunto de obligaciones con éxito.',
          pt: 'Terminar ou concluir com sucesso uma tarefa específica, atribuição ou conjunto de obrigações.',
          fr: 'Terminer ou accomplir avec succès une tâche spécifique, une affectation ou un ensemble d\'obligations.',
          it: 'Finire o completare con successo un compito specifico, un incarico o una serie di obblighi.',
          de: 'Eine bestimmte Aufgabe, einen Auftrag oder eine Reihe von Pflichten erfolgreich abschließen.'
        },
        bestContexts: 'Daily duties, work tasks, checklists, business missions, temporary goals.',
        bestContextsTranslations: {
          es: 'Deberes diarios, tareas de trabajo, listas de verificación, misiones comerciales, objetivos temporales.',
          pt: 'Deveres diários, tarefas de trabalho, listas de tarefas, missões de negócios, metas temporárias.',
          fr: 'Devoirs quotidiens, tâches de travail, listes de contrôle, missions d\'affaires, objectifs temporaires.',
          it: 'Doveri quotidiani, compiti di lavoro, liste di controllo, missioni aziendali, obiettivi temporanei.',
          de: 'Tägliche Pflichten, Arbeitsaufgaben, Checklisten, Geschäftsmissionen, vorübergehende Ziele.'
        },
        example: 'We can accomplish all tasks comfortably if we maintain strict task priorities.'
      },
      {
        word: 'Fulfill',
        meaning: 'To satisfy an inner desire, dream, hope, promise, duty, role, or standard expectation completely.',
        meaningTranslations: {
          es: 'Sastisfacer un deseo interno, sueño, esperanza, promesa, deber, rol o expectativa estándar por completo.',
          pt: 'Satisfazer completamente um desejo interno, sonho, esperança, promessa, dever, papel ou expectativa padrão.',
          fr: 'Satisfaire pleinement un désir intérieur, un rêve, un espoir, une promesse, un devoir, un rôle ou une attente standard.',
          it: 'Soddisfare completamente un desiderio interiore, un sogno, una speranza, una promessa, un dovere, un ruolo o un\'aspettativa standard.',
          de: 'Einen inneren Wunsch, Traum, eine Hoffnung, ein Versprechen, eine Pflicht, eine Rolle oder eine Standarderwartung vollständig erfüllen.'
        },
        bestContexts: 'Promises, dreams, emotional expectations, criteria, customer orders, duties.',
        bestContextsTranslations: {
          es: 'Promesas, sueños, expectativas emocionales, criterios, pedidos de clientes, deberes.',
          pt: 'Promessas, sonhos, expectativas emocionais, critérios, pedidos de clientes, deveres.',
          fr: 'Promesses, rêves, attentes émotionnelles, critères, commandes clients, devoirs.',
          it: 'Promesse, sogni, aspettative emotive, criteri, ordini dei clienti, doveri.',
          de: 'Versprechen, Träume, emotionale Erwartungen, Kriterien, Kundenbestellungen, Pflichten.'
        },
        example: 'The designer finally found a dynamic project that could fulfill her creative potential.'
      }
    ]
  },
  {
    id: 'cognitive_verbs',
    title: 'scrutinize • ponder • analyze • ignore',
    type: 'verb',
    category: 'Verbs of Intellect',
    categoryTranslations: {
      es: 'Verbos del Intelecto',
      pt: 'Verbos do Intelecto',
      fr: 'Verbes de l\'Intellect',
      it: 'Verbi dell\'Intelletto',
      de: 'Verben der Intelligenz'
    },
    subcategory: 'Mental Execution & Focus',
    subcategoryTranslations: {
      es: 'Ejecución Mental y Enfoque',
      pt: 'Execução Mental e Foco',
      fr: 'Exécution Mentale & Focalisation',
      it: 'Esecuzione Mentale e Focus',
      de: 'Mentale Ausgeglichenheit und Fokus'
    },
    description: 'Verbs used to describe how we process facts, objects, ideas, or files. These trace levels of attention from scanning for errors to ignoring them.',
    descriptionTranslations: {
      es: 'Verbos usados para describir cómo procesamos hechos, ideas, objetos o archivos. Estos rastrean niveles de atención desde escanear errores hasta ignorarlos por completo.',
      pt: 'Verbos usados para descrever como processamos fatos, ideias, objetos ou arquivos. Eles rastreiam níveis de atenção, desde a varredura de erros até sua desconsideração completa.',
      fr: 'Verbes utilisés pour décrire la façon dont nous traitons des faits, des idées, des objets ou des fichiers. Ils tracent des niveaux d\'attention allant de la détection d\'erreurs à leur ignorance totale.',
      it: 'Verbi usati per descrivere come elaboriamo fatti, idee, oggetti o file. Questi tracciano i livelli di attenzione dall\'analisi di errori all\'ignorarli del tutto.',
      de: 'Verben, die beschreiben, wie wir Fakten, Ideen, Objekte oder Dateien verarbeiten. Diese verfolgen das Ausmaß der Aufmerksamkeit, vom Scannen nach Fehlern bis hin zum vollständigen Ignorieren.'
    },
    words: [
      {
        word: 'Scrutinize',
        meaning: 'To inspect or examine something with extreme critical care, searching for any flaws or small details.',
        meaningTranslations: {
          es: 'Inspeccionar o examinar algo con extremo cuidado crítico, buscando defectos o pequeños detalles.',
          pt: 'Inspecionar ou examinar algo com extremo cuidado crítico, buscando quaisquer falhas ou pequenos detalhes.',
          fr: 'Inspecter ou examiner quelque chose avec un soin critique extrême, à la recherche de défauts ou de petits détails.',
          it: 'Ispezionare o esaminare qualcosa con estrema attenzione critica, alla ricerca di difetti o piccoli dettagli.',
          de: 'Etwas mit äußerster kritischer Sorgfalt untersuchen oder prüfen, auf der Suche nach Mängeln oder kleinen Details.'
        },
        bestContexts: 'Financial accounts, legal contracts, scientific evidence, credentials.',
        bestContextsTranslations: {
          es: 'Cuentas financieras, contratos legales, evidencia científica, credenciales.',
          pt: 'Contas financeiras, contratos de trabalho, evidências científicas, credenciais.',
          fr: 'Comptes financiers, contrats juridiques, preuves scientifiques, informations d\'identification.',
          it: 'Conti finanziari, contratti legali, prove scientifiche, credenziali.',
          de: 'Finanzkonten, rechtliche Verträge, wissenschaftliche Beweise, Referenzen.'
        },
        example: 'Security auditors will scrutinize every single line of code to verify system robustness.'
      },
      {
        word: 'Ponder',
        meaning: 'To think about or contemplate something deeply and quietly, often over a long period before a decision.',
        meaningTranslations: {
          es: 'Pensar o contemplar algo profunda y silenciosamente, a menudo durante mucho tiempo antes de tomar una decisión.',
          pt: 'Pensar ou contemplar algo profunda e silenciosamente, muitas vezes durante um longo período antes de uma decisão.',
          fr: 'Réfléchir ou contempler quelque chose profondément et calmement, souvent sur une longue période avant de décider.',
          it: 'Pensare o contemplare qualcosa in modo profondo e silenzioso, spesso per un lungo periodo prima di decidere.',
          de: 'Tief und leise über etwas nachdenken oder nachsinnen, oft über einen langen Zeitraum vor einer Entscheidung.'
        },
        bestContexts: 'Philosophical thoughts, personal decisions, career movements, options.',
        bestContextsTranslations: {
          es: 'Pensamientos filosóficos, decisiones personales, movimientos profesionales, opciones.',
          pt: 'Pensamentos filosóficos, decisões pessoais, rumos na carreira, opções.',
          fr: 'Pensées philosophiques, décisions personnelles, choix de carrière, options.',
          it: 'Pensieri filosofici, decisioni personali, movimenti di carriera, opzioni.',
          de: 'Philosophische Gedanken, persönliche Entscheidungen, Karriereschritte, Optionen.'
        },
        example: 'He stepped out onto the balcony to ponder his future role in the global enterprise.'
      },
      {
        word: 'Analyze',
        meaning: 'To study structural elements of data or a situation systematically to explain its components.',
        meaningTranslations: {
          es: 'Estudiariar los elementos estructurales de datos o de una situación sistemáticamente para explicar sus componentes.',
          pt: 'Estudar os elementos estruturais de dados ou de uma situação de forma sistemática para explicar seus componentes.',
          fr: 'Étudier systématiquement les éléments structurels de données ou d\'une situation pour expliquer ses composantes.',
          it: 'Studiare sistematicamente gli elementi strutturali di dati o di una situazione per spiegarne le componenti.',
          de: 'Strukturelle Elemente von Daten oder einer Situation systematisch untersuchen, um deren Komponenten zu erklären.'
        },
        bestContexts: 'Statistics, metrics, scientific findings, financial indices, computer logs.',
        bestContextsTranslations: {
          es: 'Estadísticas, métricas, hallazgos científicos, índices financieros, registros de computadora.',
          pt: 'Estatísticas, métricas, descobertas científicas, índices financeiros, logs de computadores.',
          fr: 'Statistiques, métriques, découvertes scientifiques, indices financiers, journaux système.',
          it: 'Statistiche, metriche, scoperte scientifiche, indici finanziari, log del computer.',
          de: 'Statistiken, Kennzahlen, wissenschaftliche Erkenntnisse, Finanzindizes, Computerprotokolle.'
        },
        example: 'Our software can analyze millions of active user feedback patterns within a fraction of a second.'
      },
      {
        word: 'Ignore',
        meaning: 'To intentionally refuse to notice, pay attention to, or address someone or something.',
        meaningTranslations: {
          es: 'Negarse intencionalmente a notar, prestar atención o abordar a alguien o algo.',
          pt: 'Recusar-se intencionalmente a notar, prestar atenção ou responder a alguém ou algo.',
          fr: 'Refuser intentionnellement de remarquer, de prêter attention ou de s\'adresser à quelqu\'un ou quelque chose.',
          it: 'Rifiutare intenzionalmente di notare, prestare attenzione o rivolgersi a qualcuno o qualcosa.',
          de: 'Sich absichtlich weigern, jemanden oder etwas zu bemerken, zu beachten oder darauf einzugehen.'
        },
        bestContexts: 'Irrelevant distractions, spam emails, negative comments, warning symptoms.',
        bestContextsTranslations: {
          es: 'Distracciones irrelevantes, correos spam, comentarios negativos, síntomas de advertencia.',
          pt: 'Distrações irrelevantes, e-mails de spam, comentários negativos, sintomas de alerta.',
          fr: 'Distractions non pertinentes, courriels indésirables, commentaires négatifs, symptômes d\'avertissement.',
          it: 'Distrazioni irrilevanti, e-mail di spam, commenti negativi, sintomi di avvertimento.',
          de: 'Irrelevante Ablenkungen, Spam-E-Mails, negative Kommentare, Warnsymptome.'
        },
        example: 'It is highly dangerous to ignore system warning levels when compiling application servers.'
      }
    ]
  }
];
