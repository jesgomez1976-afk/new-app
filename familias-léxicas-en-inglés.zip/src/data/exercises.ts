/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Exercise } from '../types';

export const interactiveExercises: Exercise[] = [
  {
    id: 'ex-1',
    type: 'fill-blank',
    instruction: 'Completa la oración transformando el verbo entre paréntesis en el ADVERBIO correcto:',
    sentenceContext: 'To handle this critical crisis, we must act _______ (decide).',
    targetWord: 'decide',
    correctAnswer: 'decisively',
    options: ['decision', 'decisively', 'decisive', 'decide'],
    wordFamilyId: 'decide',
    explanation: 'El verbo es "decide". Su adjetivo es "decisive". Para formar el adverbio de modo (cómo debemos actuar), añadimos el sufijo "-ly", resultando en "decisively".'
  },
  {
    id: 'ex-2',
    type: 'suffix-drag',
    instruction: '¿Cuál es el sufijo adecuado para convertir el verbo "arrive" en SUSTANTIVO (llegada)?',
    targetWord: 'arrive',
    correctAnswer: '-al',
    options: ['-tion', '-ment', '-al', '-ence'],
    wordFamilyId: 'arrive',
    explanation: '"Arrive" (llegar) forma su sustantivo mediante el sufijo "-al", eliminando la "e" final silenciosa: arrive + -al = arrival.'
  },
  {
    id: 'ex-3',
    type: 'pos-match',
    instruction: 'Transforma el sustantivo "energy" en ADJETIVO (enérgico):',
    targetWord: 'energy',
    correctAnswer: 'energetic',
    options: ['energize', 'energetic', 'energetically', 'energy-less'],
    wordFamilyId: 'energy',
    explanation: 'El sustantivo "energy" cambia e integra la terminación irregular "-etic" para consolidar el adjetivo "energetic".'
  },
  {
    id: 'ex-4',
    type: 'fill-blank',
    instruction: 'Completa la oración transformando el verbo entre paréntesis en SUSTANTIVO:',
    sentenceContext: 'The gradual _______ (develop) of the app took several months.',
    targetWord: 'develop',
    correctAnswer: 'development',
    options: ['develops', 'developer', 'developmental', 'development'],
    wordFamilyId: 'develop',
    explanation: '"Develop" (desarrollar) es un verbo. Para denotar el resultado de este proceso, añadimos el sufijo "-ment" para crear "development" (desarrollo).'
  },
  {
    id: 'ex-5',
    type: 'suffix-drag',
    instruction: 'Para formar el adverbio del adjetivo "energetic", ¿cuál de los siguientes sufijos se debe aplicar?',
    targetWord: 'energetic',
    correctAnswer: '-ically',
    options: ['-ly', '-ically', '-y', '-ment'],
    wordFamilyId: 'energy',
    explanation: 'De acuerdo con la regla clave, si el adjetivo de partida termina en "-ic" (como energetic), formamos el adverbio con "-ically" en lugar de "-ly". De este modo: energetic ➔ energetically.'
  },
  {
    id: 'ex-6',
    type: 'pos-match',
    instruction: 'Transforma el verbo "succeed" en ADJETIVO:',
    targetWord: 'succeed',
    correctAnswer: 'successful',
    options: ['success', 'successfully', 'successful', 'succeeding'],
    wordFamilyId: 'succeed',
    explanation: 'El verbo es "succeed", su raíz sustantiva irregular es "success". Para transformarlo en adjetivo que denota cualidad, agregamos "-ful": successful.'
  },
  {
    id: 'ex-7',
    type: 'fill-blank',
    instruction: 'Completa la oración utilizando la forma correcta de "beauty" (en este caso, en forma de VERBO):',
    sentenceContext: 'We can plant flowers to _______ (beauty) our school yard.',
    targetWord: 'beauty',
    correctAnswer: 'beautify',
    options: ['beautify', 'beautiful', 'beautifully', 'beautification'],
    wordFamilyId: 'beauty',
    explanation: '"Beauty" es un sustantivo. Para convertirlo en un verbo de acción ("embellecer"), el inglés utiliza el sufijo verbal "-ify", cambiando la "y" por "i": beautify.'
  },
  {
    id: 'ex-8',
    type: 'suffix-drag',
    instruction: '¿Qué sufijo se añade a "perform" (interpretar/despeñar) para que signifique "rendimiento/función" (sustantivo)?',
    targetWord: 'perform',
    correctAnswer: '-ance',
    options: ['-ence', '-ance', '-ment', '-tion'],
    wordFamilyId: 'perform',
    explanation: '"Perform" se transforma en sustantivo añadiendo el sufijo de estado o cualidad "-ance", dando origen a "performance".'
  },
  {
    id: 'ex-9',
    type: 'fill-blank',
    instruction: 'Completa la oración con el ADJETIVO de "danger" para indicar la propiedad peligrosa del hielo:',
    sentenceContext: 'Walking on thin ice is extremely _______ (danger).',
    targetWord: 'danger',
    correctAnswer: 'dangerous',
    options: ['dangerously', 'dangerous', 'endanger', 'dangers'],
    wordFamilyId: 'danger',
    explanation: '"Danger" es un sustantivo de peligro. Para calificar de riesgoso un estado o cosa, formamos el adjetivo con el sufijo "-ous", resultando en "dangerous".'
  },
  {
    id: 'ex-10',
    type: 'pos-match',
    instruction: 'Convierte el sustantivo "dirt" en ADVERBIO:',
    targetWord: 'dirt',
    correctAnswer: 'dirtily',
    options: ['dirty', 'dirtily', 'dirtness', 'dirtying'],
    wordFamilyId: 'dirt',
    explanation: 'El sustantivo "dirt" (tierra) se convierte en adjetivo agregando "-y" (dirty). Luego, como termina en "y", se cambia esta por "i" antes de añadir "-ly" para formar el adverbio "dirtily".'
  }
];
