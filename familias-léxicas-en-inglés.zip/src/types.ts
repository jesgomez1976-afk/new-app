/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type WordFormKey = 'verb' | 'noun' | 'adjective' | 'adverb';

export interface WordForm {
  word: string;
  suffix: string; // e.g. "-tion", "-ment", "-ly", "none" (for root / pure form)
  prefix?: string; // e.g. "un-", "in-"
  translation: string; // Spanish translation of this specific form
  definition: string; // Simple Spanish definition
  example: string; // Sentence in English
  exampleTranslation: string; // Translation we show the user
}

export interface WordFamily {
  id: string;
  lexeme: string; // El lexema / la raíz de la palabra
  lexemeDefinition: string; // Definición del lexema en español
  lexemeTranslation: string; // Traducción del lexema al español
  category: 'Éxito y Logro' | 'Creación e Intelecto' | 'Acción e Interacción' | 'Estado y Emoción';
  forms: {
    verb: WordForm | null;
    noun: WordForm | null;
    adjective: WordForm | null;
    adverb: WordForm | null;
  };
  synonyms: string[]; // Sinónimos accorde al lexema
  antonyms: string[]; // Antónimos accorde al lexema
}

export interface GrammarPattern {
  suffix: string;
  rule: string; // Regla general
  example: string; // Ej. "verb + -tion = noun"
  process: string; // Ej. "inform -> information"
}

export interface GrammarRuleSection {
  id: string;
  title: string;
  subtitle: string;
  generalRule: string;
  patterns: GrammarPattern[];
  keySecret?: string; // Regla clave / Excepción
  keySecretDetail?: string[];
}

export interface Exercise {
  id: string;
  type: 'suffix-drag' | 'fill-blank' | 'pos-match';
  instruction: string;
  sentenceContext?: string; // Sentence with blank e.g. "He completed the test _______ (success)."
  targetWord?: string; // Root word to transform e.g. "success"
  correctAnswer: string; // e.g. "successfully"
  options: string[]; // options for multi-choice or drag
  wordFamilyId: string;
  explanation: string;
}

export interface QuizAttempt {
  date: string;
  score: number;
  total: number;
  category: string;
}

export interface UserStats {
  completedExercises: string[]; // IDs of exercises solved
  quizzHistory: QuizAttempt[];
  vocabularyProgress: string[]; // WordFamily IDs explored
}
