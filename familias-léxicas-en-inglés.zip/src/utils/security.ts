/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Interface representing localized quiz statistics.
 */
export interface LocalQuizStats {
  score: number;
  total: number;
  date: string;
  category: string;
}

/**
 * Sanitizes a string by stripping HTML tags, limiting special characters, 
 * and enforcing maximum length boundaries to protect against HTML/XSS injection 
 * and UI structure breakages.
 * 
 * @param input The raw input string
 * @param maxLength The maximum allowed characters (default: 100)
 * @returns A safe, sanitized, formatted plain text string
 */
export function sanitizeString(input: unknown, maxLength = 100): string {
  if (typeof input !== 'string') {
    return '';
  }

  // Strip XML/HTML tags
  let cleaned = input.replace(/<\/?[^>]+(>|$)/g, '');

  // Truncate to avoid memory or UI injection boundaries
  if (cleaned.length > maxLength) {
    cleaned = cleaned.substring(0, maxLength);
  }

  return cleaned.trim();
}

/**
 * Validates with specific rules if a string matches a secure alphanumeric-hyphen 
 * identifier format (ideal for exercise or lesson IDs).
 * 
 * @param id The ID to evaluate
 * @returns True if the ID has a standard schema, False otherwise
 */
export function isValidIdentifier(id: unknown): boolean {
  if (typeof id !== 'string') return false;
  // Let identifiers be alphanumeric, dashes, and underscores of reasonable length (1 to 64)
  const idRegex = /^[a-zA-Z0-9_\-]+$/;
  return id.length > 0 && id.length <= 64 && idRegex.test(id);
}

/**
 * Safely accesses browser speechSynthesis engine, filtering spoken texts
 * to prevent resource exhaustion, voice-manipulation, or unauthorized commands.
 * 
 * @param text The string to read aloud.
 */
export function safeSpeech(text: string): void {
  if (!('speechSynthesis' in window)) {
    return;
  }

  // Cancel any ongoing speeches to prevent speech buffer stacking attacks
  try {
    window.speechSynthesis.cancel();
  } catch (e) {
    console.error('Speech cancellation failed:', e);
  }

  // Filter word formatting: limit length, keep printable dictionary characters only
  const sanitizedWord = text.trim().substring(0, 50);

  // Allow only alphabetic words, spaces, brackets, quotation marks, or dashes
  const speakableMatch = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s\-\(\)\"\:\,]+$/;
  if (!speakableMatch.test(sanitizedWord)) {
    console.warn('Speech synthesis request rejected for containing unsafe non-alphabetic tokens.');
    return;
  }

  try {
    const utterance = new SpeechSynthesisUtterance(sanitizedWord);
    utterance.lang = 'en-US';
    utterance.rate = 0.85; // Natural speed cadence
    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.error('Speech synthesis execution failed:', err);
  }
}

/**
 * Securely retrieves, parses, and validates the list of solved exercises from localStorage.
 * Ensures the parsed data is strictly an array containing only safe strings.
 */
export function getSafeSolvedExercises(): string[] {
  try {
    const rawData = localStorage.getItem('user_solved_exercises');
    if (!rawData) {
      return [];
    }

    const parsed = JSON.parse(rawData);
    if (!Array.isArray(parsed)) {
      console.warn('Solved exercises database was not in the expected array schema; reinitializing.');
      return [];
    }

    // Filter out invalid, suspicious identifiers to block storage manipulation attacks
    return parsed
      .map(item => typeof item === 'string' ? item : '')
      .filter(id => isValidIdentifier(id))
      .slice(0, 1000); // Enforce a defensive count limit
  } catch (err) {
    console.error('Failed to parse solved exercises safely, resetting storage view:', err);
    return [];
  }
}

/**
 * Securely commits the list of solved exercises to localStorage with strict sanitization.
 */
export function saveSafeSolvedExercises(solved: string[]): void {
  try {
    if (!Array.isArray(solved)) {
      return;
    }

    const cleanList = solved
      .map(item => typeof item === 'string' ? item : '')
      .filter(id => isValidIdentifier(id))
      .slice(0, 1100); // Cap list sizes defensively

    localStorage.setItem('user_solved_exercises', JSON.stringify(cleanList));
  } catch (err) {
    console.error('Failed to write solved exercises safely to localStorage:', err);
  }
}

/**
 * Securely retrieves, parses, and validates historical quiz scores from localStorage.
 * Ensures each item has integer boundaries and sanitized alphanumeric descriptors.
 */
export function getSafeQuizHistory(): LocalQuizStats[] {
  try {
    const rawData = localStorage.getItem('quiz_history');
    if (!rawData) {
      return [];
    }

    const parsed = JSON.parse(rawData);
    if (!Array.isArray(parsed)) {
      console.warn('Quiz history was not in the expected array schema; reinitializing.');
      return [];
    }

    const validatedHistory: LocalQuizStats[] = [];

    for (const item of parsed) {
      if (item && typeof item === 'object') {
        const rawScore = Number(item.score);
        const rawTotal = Number(item.total);

        // Score must be valid positive integers where score <= total
        const score = Number.isInteger(rawScore) && rawScore >= 0 ? rawScore : 0;
        const total = Number.isInteger(rawTotal) && rawTotal > 0 ? rawTotal : 5;
        
        // Enforce boundary constraints
        const validatedScore = Math.min(score, total);
        const validatedTotal = Math.min(total, 50); // limit abnormal quiz scales

        // Sanitize string content
        const date = sanitizeString(item.date, 30);
        const category = sanitizeString(item.category, 50);

        validatedHistory.push({
          score: validatedScore,
          total: validatedTotal,
          date: date || 'Hoy',
          category: category || 'General'
        });
      }
    }

    // Limit persistent queue history to the last 20 entries to protect local quota limits
    return validatedHistory.slice(0, 20);
  } catch (err) {
    console.error('Failed to parse quiz history safely, resetting storage view:', err);
    return [];
  }
}

/**
 * Securely commits the parsed quiz list to localStorage with formatting sanitization.
 */
export function saveSafeQuizHistory(history: LocalQuizStats[]): void {
  try {
    if (!Array.isArray(history)) {
      return;
    }

    const cleanHistory: LocalQuizStats[] = [];

    for (const item of history) {
      if (item && typeof item === 'object') {
        const rawScore = Number(item.score);
        const rawTotal = Number(item.total);

        const score = Number.isInteger(rawScore) && rawScore >= 0 ? rawScore : 0;
        const total = Number.isInteger(rawTotal) && rawTotal > 0 ? rawTotal : 5;
        
        const validatedScore = Math.min(score, total);
        const validatedTotal = Math.min(total, 50);

        cleanHistory.push({
          score: validatedScore,
          total: validatedTotal,
          date: sanitizeString(item.date, 30),
          category: sanitizeString(item.category, 50)
        });
      }
    }

    localStorage.setItem('quiz_history', JSON.stringify(cleanHistory.slice(0, 20)));
  } catch (err) {
    console.error('Failed to write quiz history safely to localStorage:', err);
  }
}

/**
 * Validates category filters dynamically to block bypass filters 
 * with unexpected payloads.
 * 
 * @param category The selected filter category.
 * @returns The sanitized category selection or default 'todos'
 */
export function validateCategoryFilter(category: unknown): string {
  if (typeof category !== 'string') return 'todos';
  const valid = ['todos', 'Éxito y Logro', 'Creación e Intelecto', 'Acción e Interacción', 'Estado y Emoción'];
  return valid.includes(category) ? category : 'todos';
}
